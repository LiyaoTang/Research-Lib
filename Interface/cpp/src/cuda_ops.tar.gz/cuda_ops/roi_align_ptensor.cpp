
#include "roi_align_ptensor.h"

#include <cassert>
#include <numeric>

#include "roi_align.h"

using paddle_mobile::PaddleTensor;
using PaddleShape = std::vector<int>;

namespace vp
{
namespace marker
{

template <typename Dtype>
static const Dtype* _data(const PaddleTensor& tensor)
{
    return reinterpret_cast<const Dtype*>(tensor.data.data());
}

template <typename Dtype>
static Dtype* _data(PaddleTensor& tensor)
{
    return reinterpret_cast<Dtype*>(tensor.data.data());
}

template <typename Dtype>
static Dtype* _mutable_data(PaddleTensor& tensor, const PaddleShape& shape)
{
    assert(!shape.empty() && shape[0] >= 0);
    const auto numel = size_t(std::accumulate(shape.cbegin(), shape.cend(),
                                              1, std::multiplies<PaddleShape::value_type>()));
    tensor.data.Resize(numel * sizeof(Dtype));
    tensor.shape = shape;
    return reinterpret_cast<Dtype*>(tensor.data.data());
}

// roi_align, tensor version, in HWC layout
template <typename FeatureDtype, typename BboxDtype>
void roi_align(
        const PaddleTensor& bottom_tensor, // HWC
        const PaddleTensor& bboxes_tensor, // NB
        PaddleTensor& top_tensor, // NHWC
        size_t pooled_height, size_t pooled_width,
        size_t sampling_ratio,
        const BboxDtype& spatial_scale,
        size_t num_threads, size_t idx_thread)
{
    auto inp_dims = bottom_tensor.shape;

    if (inp_dims.size() == 4)
    {
        assert(inp_dims[0] == 1); // 1HWC
        inp_dims.erase(inp_dims.begin());
    }

    assert(bottom_tensor.layout == paddle_mobile::LAYOUT_HWC);
    assert(inp_dims.size() == 3); // HWC
    assert(bboxes_tensor.shape.size() == 2); // NB
    assert(bboxes_tensor.shape[1] == 4); // N * 4

    const auto height = inp_dims[0];
    const auto width = inp_dims[1];
    const auto num_channels = inp_dims[2];
    const auto num_rois = bboxes_tensor.shape[0];
    const auto bottom_data_hwc = _data<FeatureDtype>(bottom_tensor);
    const auto bboxes_data_nb = _data<BboxDtype>(bboxes_tensor);

    PaddleShape out_dims {
        num_rois,
        int(pooled_height),
        int(pooled_width),
        num_channels
    };
    auto top_data_nhwc = _mutable_data<FeatureDtype>(top_tensor, out_dims);

    roi_align(bottom_data_hwc, bboxes_data_nb,
              top_data_nhwc,
              size_t(height), size_t(width), size_t(num_channels),
              pooled_height, pooled_width,
              sampling_ratio,
              spatial_scale,
              size_t(num_rois),
              num_threads, idx_thread);
}


#define ImplFeatureDtype float
#define ImplBboxDtype float

template void roi_align<ImplFeatureDtype, ImplBboxDtype>(
        const PaddleTensor& bottom_tensor, // HWC
        const PaddleTensor& bboxes_tensor, // NB
        PaddleTensor& top_tensor, // NHWC
        size_t pooled_height, size_t pooled_width,
        size_t sampling_ratio,
        const ImplBboxDtype& spatial_scale,
        size_t num_threads, size_t idx_thread);

#undef ImplBboxDtype
#undef ImplFeatureDtype

} //namespace marker
} // namespace vp
