
#pragma once

#include <cstddef>

#include "framework/operator.h"
#include "operators/op_param.h"

namespace vp
{
namespace marker
{

namespace frw = paddle_mobile::framework;
namespace ops = paddle_mobile::operators;

using IouType = float;

//template <>
class NmsParam:
        public ops::OpParam
{
    using GType = frw::Tensor;
    using RType = frw::Tensor;

    bool output_bboxes_ = false;
    IouType threshold_;
    size_t top_k_;

    RType *bboxes_ = nullptr;
    RType *out_indices_ = nullptr, *out_bboxes_ = nullptr;

public:
    NmsParam(const paddle_mobile::VariableNameMap &inputs,
             const paddle_mobile::VariableNameMap &outputs,
             const frw::AttributeMap &attrs,
             const frw::Scope &scope)
    {
        output_bboxes_ = GetAttr<bool>("output_bboxes", attrs);
        threshold_ = GetAttr<IouType>("threshold", attrs);
        top_k_ = GetAttr<size_t>("top_k", attrs);

        bboxes_ = InputBBoxesFrom<GType>(inputs, scope);

        if (!output_bboxes_)
        {
            out_indices_ = GetVarValue<GType>("OutIndices", outputs, scope);
        }
        else
        {
            out_bboxes_ = GetVarValue<GType>("OutBboxes", outputs, scope);
        }
    }

    IouType Threshold() const
    {
        return threshold_;
    }

    size_t TopK() const
    {
        return top_k_;
    }

    bool OutputBboxes() const
    {
        return output_bboxes_;
    }

    const RType* Bboxes() const
    {
        assert(bboxes_ != nullptr);
        return bboxes_;
    }

    RType* OutIndices() const
    {
        assert(!output_bboxes_);
        assert(out_indices_ != nullptr);
        return out_indices_;
    }

    RType* OutBboxes() const
    {
        assert(output_bboxes_);
        assert(out_bboxes_ != nullptr);
        return out_bboxes_;
    }

};

template <typename DeviceType, typename BboxDtype, typename IndexDtype>
class NmsKernel:
        public frw::OpKernelBase<DeviceType, NmsParam>
{
public:
    bool Init(NmsParam* param) { return true; }
    void Compute(const NmsParam& param);
};

//template <>
class NmsUnorderedParam:
    public ops::OpParam
{
    using GType = frw::Tensor;
    using RType = frw::Tensor;

    bool output_bboxes_ = false;
    IouType threshold_;
    size_t top_k_;

    RType *bboxes_ = nullptr, *scores_ = nullptr;
    RType *out_indices_ = nullptr, *out_bboxes_ = nullptr;

public:
    NmsUnorderedParam(const paddle_mobile::VariableNameMap &inputs,
                      const paddle_mobile::VariableNameMap &outputs,
                      const frw::AttributeMap &attrs,
                      const frw::Scope &scope)
    {
        output_bboxes_ = GetAttr<bool>("output_bboxes", attrs);
        threshold_ = GetAttr<IouType>("threshold", attrs);
        top_k_ = GetAttr<size_t>("top_k", attrs);

        bboxes_ = InputBBoxesFrom<GType>(inputs, scope);
        scores_ = InputScoresFrom<GType>(inputs, scope);

        if (!output_bboxes_)
        {
            out_indices_ = GetVarValue<GType>("OutIndices", outputs, scope);
        }
        else
        {
            out_bboxes_ = GetVarValue<GType>("OutBboxes", outputs, scope);
        }
    }

    IouType Threshold() const
    {
        return threshold_;
    }

    size_t TopK() const
    {
        return top_k_;
    }

    bool OutputBboxes() const
    {
        return output_bboxes_;
    }

    const RType* Bboxes() const
    {
        assert(bboxes_ != nullptr);
        return bboxes_;
    }

    const RType* Scores() const
    {
        assert(scores_ != nullptr);
        return scores_;
    }

    RType* OutIndices() const
    {
        assert(!output_bboxes_);
        assert(out_indices_ != nullptr);
        return out_indices_;
    }

    RType* OutBboxes() const
    {
        assert(output_bboxes_);
        assert(out_bboxes_ != nullptr);
        return out_bboxes_;
    }

};

template <typename DeviceType, typename BboxDtype, typename ScoreDtype, typename IndexDtype>
class NmsUnorderedKernel:
        public frw::OpKernelBase<DeviceType, NmsUnorderedParam>
{
public:
    bool Init(NmsUnorderedParam* param) { return true; }
    void Compute(const NmsUnorderedParam& param);
};

} //namespace marker
} // namespace vp
