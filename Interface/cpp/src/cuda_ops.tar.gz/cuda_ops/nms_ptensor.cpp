
#include "nms_ptensor.h"

#include <cassert>
#include <numeric>

#include "nms.h"

using paddle_mobile::PaddleTensor;
using PaddleShape = std::vector<int>;

namespace vp
{
namespace marker
{

static size_t _numel(const PaddleShape& shape)
{
    size_t numel = 0;

    if (!shape.empty())
    {
        if (shape[0] < 0)
        {
            if (shape.size() > 1)
            {
                numel = size_t(std::accumulate(shape.cbegin() + 1, shape.cend(),
                                              1, std::multiplies<PaddleShape::value_type>()));
            }
        }

        numel = size_t(std::accumulate(shape.cbegin(), shape.cend(),
                                      1, std::multiplies<PaddleShape::value_type>()));
    }

    return numel;
}

static size_t _numel(const PaddleTensor& tensor)
{
    const auto shape = tensor.shape;
    const auto numel = _numel(shape);
//    assert(numel * sizeof  <= tensor.data.length());
    return numel;
}

template <typename Dtype>
static const Dtype* _data(const PaddleTensor& tensor)
{
    return reinterpret_cast<const Dtype*>(tensor.data.data());
}

template <typename Dtype>
static Dtype* _data(PaddleTensor& tensor)
{
    return reinterpret_cast<Dtype*>(tensor.data.data());
}

template <typename Dtype>
static Dtype* _mutable_data(PaddleTensor& tensor, const PaddleShape& shape)
{
    const auto numel = _numel(shape);
    tensor.data.Resize(sizeof(Dtype) * numel);
    tensor.shape = shape;
    return reinterpret_cast<Dtype*>(tensor.data.data());
}

// nms, tensor version, output indices
template <typename BboxDtype,
          typename IndexDtype, typename IouType>
auto nms(
        const PaddleTensor& bboxes_tensor,
        PaddleTensor& out_tensor,
        const IouType& threshold,
        size_t top_k)
    -> typename std::enable_if<!std::is_same<IndexDtype, void>::value, size_t>::type
{
    // empty input specialization
    if (_numel(bboxes_tensor) == 0)
    {
        out_tensor.shape = { 0 };
        return 0;
    }

    assert(bboxes_tensor.shape.size() == 2); // NB
    assert(bboxes_tensor.shape[1] == 4); // N * 4

    const auto num_rois = bboxes_tensor.shape[0];
    const auto bboxes_data_nb = _data<BboxDtype>(bboxes_tensor);

    PaddleTensor area_tensor;
    auto area_data = _mutable_data<BboxDtype>(area_tensor, { num_rois });
    auto out_indices_data = _mutable_data<IndexDtype>(out_tensor, { num_rois });

    const auto num_selected = nms_index(
                bboxes_data_nb,
                out_indices_data,
                area_data,
                size_t(num_rois),
                threshold,
                top_k);

    out_tensor.shape = { int(num_selected) };
    return num_selected;
}

// nms, tensor version, output bboxes
template <typename BboxDtype,
          typename IndexDtype, typename IouType>
auto nms(
        const PaddleTensor& bboxes_tensor,
        PaddleTensor& out_tensor,
        const IouType& threshold,
        size_t top_k)
    -> typename std::enable_if<std::is_same<IndexDtype, void>::value, size_t>::type
{
    // empty input specialization
    if (_numel(bboxes_tensor) == 0)
    {
        out_tensor.shape = bboxes_tensor.shape;
        return 0;
    }

    assert(bboxes_tensor.shape.size() == 2); // NB
    assert(bboxes_tensor.shape[1] == 4); // N * 4

    const auto num_rois = bboxes_tensor.shape[0];
    const auto bboxes_data_nb = _data<BboxDtype>(bboxes_tensor);

    PaddleTensor indices_tensor, area_tensor;
    auto indices_data = _mutable_data<size_t>(indices_tensor, { num_rois });
    auto area_data = _mutable_data<BboxDtype>(area_tensor, { num_rois });
    auto out_dims = bboxes_tensor.shape;
    auto out_bboxes_data_nb = _mutable_data<BboxDtype>(out_tensor, out_dims);

    const auto num_selected = nms_bbox(
                bboxes_data_nb,
                out_bboxes_data_nb,
                indices_data, area_data,
                size_t(num_rois),
                threshold,
                top_k);

    out_dims[0] = num_selected;
    out_tensor.shape = out_dims;
    return num_selected;
}

// nms_unordered, tensor version, output indices
template <typename BboxDtype, typename ScoreDtype,
          typename IndexDtype, typename IouType>
auto nms(
        const PaddleTensor& bboxes_tensor, const PaddleTensor& scores_tensor,
        PaddleTensor& out_tensor,
        const IouType& threshold,
        size_t top_k)
    -> typename std::enable_if<!std::is_same<IndexDtype, void>::value, size_t>::type
{
    // empty input specialization
    if (_numel(bboxes_tensor) == 0)
    {
        out_tensor.shape = { 0 };
        return 0;
    }

    assert(bboxes_tensor.shape.size() == 2); // NB
    assert(bboxes_tensor.shape[1] == 4); // N * 4

    const auto num_rois = bboxes_tensor.shape[0];

    assert(scores_tensor.shape.size() == 1); // N
    assert(num_rois == scores_tensor.shape[0]); // N == N

    const auto bboxes_data_nb = _data<BboxDtype>(bboxes_tensor);
    const auto scores_data = _data<ScoreDtype>(scores_tensor);

    PaddleTensor area_tensor;
    auto area_data = _mutable_data<BboxDtype>(area_tensor, { num_rois });
    auto out_indices_data = _mutable_data<IndexDtype>(out_tensor, { num_rois });

    const auto num_selected = nms_index(
                bboxes_data_nb, scores_data,
                out_indices_data,
                area_data,
                size_t(num_rois),
                threshold,
                top_k);

    out_tensor.shape = { int(num_selected) };
    return num_selected;
}

// nms_unordered, tensor version, output bboxes
template <typename BboxDtype, typename ScoreDtype,
          typename IndexDtype, typename IouType>
auto nms(
        const PaddleTensor& bboxes_tensor, const PaddleTensor& scores_tensor,
        PaddleTensor& out_tensor,
        const IouType& threshold,
        size_t top_k)
    -> typename std::enable_if<std::is_same<IndexDtype, void>::value, size_t>::type
{
    // empty input specialization
    if (_numel(bboxes_tensor) == 0)
    {
        out_tensor.shape = bboxes_tensor.shape;
        return 0;
    }

    assert(bboxes_tensor.shape.size() == 2); // NB
    assert(bboxes_tensor.shape[1] == 4); // N * 4

    const auto num_rois = bboxes_tensor.shape[0];

    assert(scores_tensor.shape.size() == 1); // N
    assert(num_rois == scores_tensor.shape[0]); // N == N

    const auto bboxes_data_nb = _data<BboxDtype>(bboxes_tensor);
    const auto scores_data = _data<ScoreDtype>(scores_tensor);

    PaddleTensor indices_tensor, area_tensor;
    auto indices_data = _mutable_data<size_t>(indices_tensor, { num_rois });
    auto area_data = _mutable_data<BboxDtype>(area_tensor, { num_rois });
    auto out_dims = bboxes_tensor.shape;
    auto out_bboxes_data_nb = _mutable_data<BboxDtype>(out_tensor, out_dims);

    const auto num_selected = nms_bbox(
                bboxes_data_nb, scores_data,
                out_bboxes_data_nb,
                indices_data, area_data,
                size_t(num_rois),
                threshold,
                top_k);

    out_dims[0] = num_selected;
    out_tensor.shape = out_dims;
    return num_selected;
}


#define ImplBboxDtype float
#define ImplIndexDtype int64_t

template size_t nms<ImplBboxDtype, ImplIndexDtype>(
        const PaddleTensor&,
        PaddleTensor&,
        const float& threshold,
        size_t top_k);

template size_t nms<ImplBboxDtype>(
        const PaddleTensor&,
        PaddleTensor&,
        const float& threshold,
        size_t top_k);

#define ImplScoreDtype float

template size_t nms<ImplBboxDtype, ImplScoreDtype, ImplIndexDtype>(
        const PaddleTensor&, const PaddleTensor&,
        PaddleTensor&,
        const float& threshold,
        size_t top_k);

template size_t nms<ImplBboxDtype, ImplScoreDtype>(
        const PaddleTensor&, const PaddleTensor&,
        PaddleTensor&,
        const float& threshold,
        size_t top_k);

#undef ImplScoreDtype
#undef ImplIndexDtype
#undef ImplBboxDtype

} //namespace marker
} // namespace vp
