
#pragma once

#include <cstddef>

#include "framework/operator.h"
#include "operators/op_param.h"

namespace vp
{
namespace marker
{

namespace frw = paddle_mobile::framework;
namespace ops = paddle_mobile::operators;

template <typename BboxDtype>
class RoiAlignParam:
        public ops::OpParam
{
    using GType = frw::Tensor;
    using RType = frw::Tensor;

    size_t pooled_height_, pooled_width_, sampling_ratio_;
    BboxDtype spatial_scale_;

    RType *feature_ = nullptr, *bboxes_ = nullptr;
    RType *out_features_ = nullptr;

public:
    RoiAlignParam(const paddle_mobile::VariableNameMap &inputs,
             const paddle_mobile::VariableNameMap &outputs,
             const frw::AttributeMap &attrs,
             const frw::Scope &scope)
    {
        pooled_height_ = GetAttr<size_t>("pooled_height", attrs);
        pooled_width_ = GetAttr<size_t>("pooled_width", attrs);
        sampling_ratio_ = GetAttr<size_t>("sampling_ratio", attrs);
        spatial_scale_ = GetAttr<BboxDtype>("spatial_scale", attrs);

        feature_ = InputXFrom<GType>(inputs, scope);
        bboxes_ = InputBBoxesFrom<GType>(inputs, scope);
        out_features_ = OutputYFrom<GType>(outputs, scope);
    }

    size_t PooledHeight() const
    {
        return pooled_height_;
    }

    size_t PooledWidth() const
    {
        return pooled_width_;
    }

    size_t SamplingRatio() const
    {
        return sampling_ratio_;
    }

    BboxDtype SpatialScale() const
    {
        return spatial_scale_;
    }

    const RType* Feature() const
    {
        assert(feature_ != nullptr);
        return feature_;
    }

    const RType* Bboxes() const
    {
        assert(bboxes_ != nullptr);
        return bboxes_;
    }

    RType* OutFeatures() const
    {
        assert(out_features_ != nullptr);
        return out_features_;
    }
};

template <typename DeviceType, typename FeatureDtype, typename BboxDtype>
class RoiAlignKernel:
        public frw::OpKernelBase<DeviceType, RoiAlignParam<BboxDtype>>
{
public:
    bool Init(RoiAlignParam<BboxDtype>* param) { return true; }
    void Compute(const RoiAlignParam<BboxDtype>& param);
};

} //namespace marker
} // namespace vp

