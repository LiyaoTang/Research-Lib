
#include "postprocess_tensor.h"

#include <cassert>

#include "postprocess.h"

namespace frw = paddle_mobile::framework;

namespace vp
{
namespace marker
{

// index_select on dim 0, tensor version
template <typename TD, typename TI>
void index_select(
        const frw::Tensor& src_tensor, // N...
        const frw::Tensor& indices_tensor, // M
        frw::Tensor& dst_tensor)
{
    assert(src_tensor.dims().size() >= 1); // N...
    assert(indices_tensor.dims().size() == 1); // M

    const auto src_data = src_tensor.data<TD>();
    const auto indices_data = indices_tensor.data<TI>();

    const auto count = indices_tensor.dims()[0];
    const auto group_size = indices_tensor.numel() / count;

    auto out_dims = src_tensor.dims();
    out_dims[0] = count;

    auto dst_data = dst_tensor.mutable_data<TD>(out_dims);

    index_select(src_data, indices_data, dst_data,
                 size_t(count),
                 size_t(group_size));
}

// roi_filter, tensor + inplace version
template <typename ProbDtype, typename LabelDtype, typename BboxDtype,
          bool B8TO4>
size_t roi_filter(
        const frw::Tensor& cls_prob_tensor, // NC
        frw::Tensor& scores_tensor, // N
        frw::Tensor& labels_tensor, // N
        frw::Tensor& bboxes_tensor, // NB, inplace
        const ProbDtype& score_threshold,
        const BboxDtype& area_threshold,
        const BboxDtype& xmin, const BboxDtype& xmax,
        const BboxDtype& ymin, const BboxDtype& ymax)
{
    assert(cls_prob_tensor.dims().size() == 2); // NC
    assert(bboxes_tensor.dims().size() == 2); // NB
    assert(bboxes_tensor.dims()[1] == (B8TO4 ? 8 : 4)); // N * (4 or 8)

    const auto num_rois = cls_prob_tensor.dims()[0];
    const auto num_labels = cls_prob_tensor.dims()[1];
    const auto cls_prob_data = cls_prob_tensor.data<ProbDtype>();

    assert(num_rois == bboxes_tensor.dims()[0]); // N == N

    auto scores_data = scores_tensor.mutable_data<ProbDtype>({ num_rois });
    auto labels_data = labels_tensor.mutable_data<LabelDtype>({ num_rois });
    auto bboxes_data_nb = bboxes_tensor.data<BboxDtype>();

    const auto num_filterd = roi_filter<ProbDtype, LabelDtype, BboxDtype, B8TO4>(
                cls_prob_data,
                scores_data,
                labels_data,
                bboxes_data_nb,
                size_t(num_rois), size_t(num_labels),
                score_threshold,
                area_threshold,
                xmin, xmax,
                ymin, ymax);

    scores_tensor.Resize({ int64_t(num_filterd) });
    labels_tensor.Resize({ int64_t(num_filterd) });
    bboxes_tensor.Resize({ int64_t(num_filterd), 4 }); // ensured to be 4
    return num_filterd;
}

// roi_filter, with anchors, tensor + inplace version
template <typename ProbDtype, typename LabelDtype, typename BboxDtype,
          bool B8TO4>
size_t roi_filter(
        const frw::Tensor& cls_prob_tensor, // NC
        frw::Tensor& scores_tensor, // N
        frw::Tensor& labels_tensor, // N
        frw::Tensor& bboxes_tensor, // NB, inplace
        frw::Tensor& anchors_tensor, // NB, inplace
        const ProbDtype& score_threshold,
        const BboxDtype& area_threshold,
        const BboxDtype& xmin, const BboxDtype& xmax,
        const BboxDtype& ymin, const BboxDtype& ymax)
{
    assert(cls_prob_tensor.dims().size() == 2); // NC
    assert(bboxes_tensor.dims().size() == 2); // NB
    assert(bboxes_tensor.dims()[1] == (B8TO4 ? 8 : 4)); // N * (4 or 8)
    assert(anchors_tensor.dims().size() == 2); // NB
    assert(anchors_tensor.dims()[1] == 4); // N * 4

    const auto num_rois = cls_prob_tensor.dims()[0];
    const auto num_labels = cls_prob_tensor.dims()[1];
    const auto cls_prob_data = cls_prob_tensor.data<ProbDtype>();

    assert(num_rois == bboxes_tensor.dims()[0]); // N == N
    assert(num_rois == anchors_tensor.dims()[0]); // N == N

    auto scores_data = scores_tensor.mutable_data<ProbDtype>({ num_rois });
    auto labels_data = labels_tensor.mutable_data<LabelDtype>({ num_rois });
    auto bboxes_data_nb = bboxes_tensor.data<BboxDtype>();
    auto anchors_data_nb = anchors_tensor.data<BboxDtype>();

    const auto num_filterd = roi_filter<ProbDtype, LabelDtype, BboxDtype, B8TO4>(
                cls_prob_data,
                scores_data,
                labels_data,
                bboxes_data_nb,
                anchors_data_nb,
                size_t(num_rois), size_t(num_labels),
                score_threshold,
                area_threshold,
                xmin, xmax,
                ymin, ymax);

    scores_tensor.Resize({ int64_t(num_filterd) });
    labels_tensor.Resize({ int64_t(num_filterd) });
    bboxes_tensor.Resize({ int64_t(num_filterd), 4 }); // ensured to be 4
    anchors_tensor.Resize({ int64_t(num_filterd), 4 }); // ensured to be 4
    return num_filterd;
}

// bbox_xywh2xyxy, tensor + inplace version
template <typename BboxDtype>
void bbox_xywh2xyxy(frw::Tensor& bboxes_tensor) // NB
{
    assert(bboxes_tensor.dims().size() == 2); // NB
    assert(bboxes_tensor.dims()[1] == 4); // N * 4

    const auto num_rois = bboxes_tensor.dims()[0];

    auto bboxes_data_nb = bboxes_tensor.data<BboxDtype>();

    bbox_xywh2xyxy(bboxes_data_nb,
                   size_t(num_rois));
}

// bbox_decode, tensor + inplace version
template <typename BboxDtype>
void bbox_decode(
        frw::Tensor& bboxes_tensor, // NB, inplace
        const frw::Tensor& anchors_tensor, // NB
        BboxDtype rweight_cx, BboxDtype rweight_cy,
        BboxDtype rweight_width, BboxDtype rweight_height)
{
    assert(bboxes_tensor.dims().size() == 2); // NB
    assert(bboxes_tensor.dims()[1] == 4); // N *
    assert(anchors_tensor.dims().size() == 2); // NB
    assert(anchors_tensor.dims()[1] == 4); // N * 4

    const auto num_rois = bboxes_tensor.dims()[0];

    assert(num_rois == anchors_tensor.dims()[0]); // N == N

    const auto anchors_data_nb = anchors_tensor.data<BboxDtype>();

    auto bboxes_data_nb = bboxes_tensor.data<BboxDtype>();

    bbox_decode(bboxes_data_nb,
                anchors_data_nb,
                size_t(num_rois),
                rweight_cx, rweight_cy,
                rweight_width, rweight_height);
}

// marker_postprocess, tensor + inplace version
template <typename KeypointDtype, typename BboxDtype>
void marker_postprocess(
        frw::Tensor& keypoints_tensor,
        const frw::Tensor& bboxes_tensor,
        BboxDtype rweight)
{
    const size_t num_keypoints = 4;

    assert(keypoints_tensor.dims().size() == 2); // NP
    assert(keypoints_tensor.dims()[1] == num_keypoints * 2); // N * (P * 2)
    assert(bboxes_tensor.dims().size() == 2); // NB
    assert(bboxes_tensor.dims()[1] == 4); // N * 4

    const auto num_rois = keypoints_tensor.dims()[0];

    assert(num_rois == bboxes_tensor.dims()[0]);

    const auto bboxes_data_nb = bboxes_tensor.data<BboxDtype>();

    auto keypoints_data_np = keypoints_tensor.data<KeypointDtype>();

    keypoint_postprocess(
                keypoints_data_np,
                bboxes_data_nb,
                size_t(num_rois), num_keypoints,
                rweight, rweight);
}


#define ImplTI int64_t
#define ImplTD float

template void index_select<ImplTD, ImplTI>(
        const frw::Tensor& src_tensor, // N...
        const frw::Tensor& indices_tensor, // M
        frw::Tensor& dst_tensor);

#undef ImplTD
#define ImplTD int64_t

template void index_select<ImplTD, ImplTI>(
        const frw::Tensor& src_tensor, // N...
        const frw::Tensor& indices_tensor, // M
        frw::Tensor& dst_tensor);

#undef ImplTD
#undef ImplTI

#define ImplProbDtype float
#define ImplLabelDtype int64_t
#define ImplBboxDtype float

template size_t roi_filter<ImplProbDtype, ImplLabelDtype, ImplBboxDtype, false>(
        const frw::Tensor& cls_prob_tensor, // NC
        frw::Tensor& scores_tensor, // N
        frw::Tensor& labels_tensor, // N
        frw::Tensor& bboxes_tensor, // NB, inplace
        const ImplProbDtype& score_threshold,
        const ImplBboxDtype& area_threshold,
        const ImplBboxDtype& xmin, const ImplBboxDtype& xmax,
        const ImplBboxDtype& ymin, const ImplBboxDtype& ymax);

template size_t roi_filter<ImplProbDtype, ImplLabelDtype, ImplBboxDtype, true>(
        const frw::Tensor& cls_prob_tensor, // NC
        frw::Tensor& scores_tensor, // N
        frw::Tensor& labels_tensor, // N
        frw::Tensor& bboxes_tensor, // NB, inplace
        const ImplProbDtype& score_threshold,
        const ImplBboxDtype& area_threshold,
        const ImplBboxDtype& xmin, const ImplBboxDtype& xmax,
        const ImplBboxDtype& ymin, const ImplBboxDtype& ymax);

template size_t roi_filter<ImplProbDtype, ImplLabelDtype, ImplBboxDtype, false>(
        const frw::Tensor& cls_prob_tensor, // NC
        frw::Tensor& scores_tensor, // N
        frw::Tensor& labels_tensor, // N
        frw::Tensor& bboxes_tensor, // NB, inplace
        frw::Tensor& anchors_tensor, // NB, inplace
        const ImplProbDtype& score_threshold,
        const ImplBboxDtype& area_threshold,
        const ImplBboxDtype& xmin, const ImplBboxDtype& xmax,
        const ImplBboxDtype& ymin, const ImplBboxDtype& ymax);

template size_t roi_filter<ImplProbDtype, ImplLabelDtype, ImplBboxDtype, true>(
        const frw::Tensor& cls_prob_tensor, // NC
        frw::Tensor& scores_tensor, // N
        frw::Tensor& labels_tensor, // N
        frw::Tensor& bboxes_tensor, // NB, inplace
        frw::Tensor& anchors_tensor, // NB, inplace
        const ImplProbDtype& score_threshold,
        const ImplBboxDtype& area_threshold,
        const ImplBboxDtype& xmin, const ImplBboxDtype& xmax,
        const ImplBboxDtype& ymin, const ImplBboxDtype& ymax);

#undef ImplProbDtype
#undef ImplLabelDtype

template void bbox_xywh2xyxy<ImplBboxDtype>(frw::Tensor& bboxes_tensor);

template void bbox_decode<ImplBboxDtype>(
        frw::Tensor& bboxes_tensor, // NB, inplace
        const frw::Tensor& anchors_tensor, // NB
        ImplBboxDtype rweight_cx, ImplBboxDtype rweight_cy,
        ImplBboxDtype rweight_width, ImplBboxDtype rweight_height);

#define ImplKeypointDtype float

template void marker_postprocess<ImplKeypointDtype, ImplBboxDtype>(
        frw::Tensor& keypoints_tensor, // NB, inplace
        const frw::Tensor& bboxes_tensor, // NB
        ImplBboxDtype rweight);

#undef ImplKeypointDtype
#undef ImplBboxDtype

} //namespace marker
} // namespace vp
