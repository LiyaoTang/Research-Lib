
#include "postprocess.h"

#include <algorithm>
#include <cassert>
#include <cmath>

namespace vp
{
namespace marker
{

// area
#pragma omp declare simd
template <typename TB>
static TB area(const TB* __restrict__ const bbox)
{
    const auto& x0 = bbox[0];
    const auto& y0 = bbox[1];
    const auto& x1 = bbox[2];
    const auto& y1 = bbox[3];

    return (x1 + 1 - x0) * (y1 + 1 - y0);
}

// clamp into image size
#pragma omp declare simd
template <typename TB>
static void bbox_clip(TB* __restrict__ const bbox,
               const TB& xmin, const TB& xmax,
               const TB& ymin, const TB& ymax)
{
    bbox[0] = std::max(xmin, bbox[0]);
    bbox[1] = std::max(ymin, bbox[1]);
    bbox[2] = std::min(xmax, bbox[2]);
    bbox[3] = std::min(ymax, bbox[3]);
}

// select on dim 0
template <typename TD, typename TI>
void index_select(
        const TD* __restrict__ const src_data,
        const TI* __restrict__ const indices_data,
        TD* __restrict__ const dst_data,
        size_t count,
        size_t group_size)
{
    auto ptr_dst = dst_data;

#pragma omp for
    for (size_t idx = 0; idx < count; ++idx)
    {
        ptr_dst = std::copy_n(src_data + indices_data[idx] * group_size,
                              group_size, ptr_dst);
    }
}

// roi_filter, raw + inplace version
template <typename TP, typename TL, typename TB,
          bool B8TO4>
size_t roi_filter(
        const TP* __restrict__ const cls_prob_data_nc,
        TP* __restrict__ const scores_data,
        TL* __restrict__ const labels_data,
        TB* __restrict__ const bboxes_data_nb, // inplace
        size_t num_rois, size_t num_labels,
        const TP& score_threshold,
        const TB& area_threshold,
        const TB& xmin, const TB& xmax, const TB& ymin, const TB& ymax)
{
    assert(num_labels > 1); // enforce: background and others

    auto ptr_prob = cls_prob_data_nc;
    size_t idx_dst = 0;

#pragma omp for
    for (size_t idx_roi = 0; idx_roi < num_rois; ++idx_roi)
    {
        auto max_val = *(ptr_prob++);
        size_t max_pos = 0;
        for (size_t idx_label = 1; idx_label < num_labels; ++idx_label)
        {
            const auto val = *(ptr_prob++);
            if (max_val < val)
            {
                max_val = val;
                max_pos = idx_label;
            }
        }

        // filter background(label == 0)
        if (max_pos == 0 || max_val <= score_threshold)
        {
            continue;
        }

        const auto src_bbox = B8TO4 ?
                    bboxes_data_nb + idx_roi * 8 + 4:
                    bboxes_data_nb + idx_roi * 4;
        const auto box_area = area(src_bbox);

        if (box_area <= area_threshold)
        {
            continue;
        }

        scores_data[idx_dst] = max_val;
        labels_data[idx_dst] = TL(max_pos);

        // inplace filter, ensure idx_roi ascending
        auto dst_bbox = bboxes_data_nb + idx_dst * 4;
        std::copy_n(src_bbox, 4, dst_bbox);
        bbox_clip(dst_bbox, xmin, xmax, ymin, ymax);

        ++idx_dst;
    }

    return idx_dst;
}

// roi_filter, with anchors, raw + inplace version
template <typename TP, typename TL, typename TB,
          bool B8TO4>
size_t roi_filter(
        const TP* __restrict__ const cls_prob_data_nc,
        TP* __restrict__ const scores_data,
        TL* __restrict__ const labels_data,
        TB* __restrict__ const bboxes_data_nb, // inplace
        TB* __restrict__ const anchors_data_nb, // inplace
        size_t num_rois, size_t num_labels,
        const TP& score_threshold,
        const TB& area_threshold,
        const TB& xmin, const TB& xmax, const TB& ymin, const TB& ymax)
{
    assert(num_labels > 1); // enforce: background and others

    auto ptr_prob = cls_prob_data_nc;
    size_t idx_dst = 0;

#pragma omp for
    for (size_t idx_roi = 0; idx_roi < num_rois; ++idx_roi)
    {
        auto max_val = *(ptr_prob++);
        size_t max_pos = 0;
        for (size_t idx_label = 1; idx_label < num_labels; ++idx_label)
        {
            const auto val = *(ptr_prob++);
            if (max_val < val)
            {
                max_val = val;
                max_pos = idx_label;
            }
        }

        // filter background(label == 0)
        if (max_pos == 0 || max_val <= score_threshold)
        {
            continue;
        }

        const auto src_anchor = anchors_data_nb + idx_roi * 4;
        const auto box_area = area(src_anchor);

        if (box_area <= area_threshold)
        {
            continue;
        }

        scores_data[idx_dst] = max_val;
        labels_data[idx_dst] = TL(max_pos);

        // inplace filter, ensure idx_roi ascending
        const auto src_bbox = B8TO4 ?
                    bboxes_data_nb + idx_roi * 8 + 4:
                    bboxes_data_nb + idx_roi * 4;
        auto dst_bbox = bboxes_data_nb + idx_dst * 4;
        std::copy_n(src_bbox, 4, dst_bbox);
        bbox_clip(dst_bbox, xmin, xmax, ymin, ymax);
        auto dst_anchor = anchors_data_nb + idx_dst * 4;
        std::copy_n(src_anchor, 4, dst_anchor);
        bbox_clip(dst_anchor, xmin, xmax, ymin, ymax);

        ++idx_dst;
    }

    return idx_dst;
}

// bbox_xywh2xyxy, raw + inplace version
template <typename TB>
void bbox_xywh2xyxy(
        TB* __restrict__ const bboxes_data_nb, // inplace, rel xywh form -> abs xyxy form
        size_t num_rois,
        const TB& extra)
{
#pragma omp simd
    for (size_t idx_n = 0; idx_n < num_rois; ++idx_n)
    {
        auto bbox = bboxes_data_nb + idx_n * 4;
//        bbox[0] = bbox[0];
//        bbox[1] = bbox[1];
        bbox[2] = bbox[0] + std::max(TB(0), bbox[2] - extra);
        bbox[3] = bbox[1] + std::max(TB(0), bbox[3] - extra);
    }
}

// bbox_decode, raw + inplace version
template <typename TB>
void bbox_decode(
        TB* __restrict__ const bboxes_data_nb, // inplace, rel xywh form -> abs xyxy form
        const TB* __restrict__ const anchors_data_nb,
        size_t num_rois,
        const TB& rweight_cx, const TB& rweight_cy,
        const TB& rweight_width, const TB& rweight_height,
        const TB& extra)
{
#pragma omp simd
    for (size_t idx_n = 0; idx_n < num_rois; ++idx_n)
    {
        const auto anchor = anchors_data_nb + idx_n * 4;
        const auto width = anchor[2] + extra - anchor[0];
        const auto height = anchor[3] + extra - anchor[1];

        auto bbox = bboxes_data_nb + idx_n * 4;
        auto hw = width / 2;
        auto hh = height / 2;
        auto cx = anchor[0] + hw;
        auto cy = anchor[1] + hh;

        cx += bbox[0] * width * rweight_cx;
        cy += bbox[1] * height * rweight_cy;
        hw *= std::exp(bbox[2] * rweight_width);
        hh *= std::exp(bbox[3] * rweight_height);

        bbox[0] = cx - hw;
        bbox[1] = cy - hh;
        bbox[2] = cx + hw - extra;
        bbox[3] = cy + hh - extra;
    }
}

// keypoint_postprocess, raw + inplace version
template <typename TK, typename TB>
void keypoint_postprocess(
        TK* __restrict__ const keypoints_data_np, // inplace, rel xyxy form -> abs xyxy form
        const TB* __restrict__ const bboxes_data_nb,
        size_t num_rois, size_t num_keypoints,
        const TB& rweight_x, const TB& rweight_y)
{
#pragma omp for
    for (size_t idx_n = 0; idx_n < num_rois; ++idx_n)
    {
        const auto bbox = bboxes_data_nb + idx_n * 4;
        const auto cx = (bbox[0] + bbox[2]) / 2;
        const auto cy = (bbox[1] + bbox[3]) / 2;
        const auto scaled_width = (bbox[2] - bbox[0]) * rweight_x;
        const auto scaled_height = (bbox[3] - bbox[1]) * rweight_y;

        auto keypoints_data_p = keypoints_data_np + idx_n * num_keypoints * 2;

        size_t idx = 0;

#pragma omp simd
        for (size_t idx_p = 0; idx_p < num_keypoints; ++idx_p)
        {
            keypoints_data_p[idx] = cx + keypoints_data_p[idx] * scaled_width;
            ++idx;
            keypoints_data_p[idx] = cy + keypoints_data_p[idx] * scaled_height;
            ++idx;
        }
    }
}

#define ImplTI int64_t
#define ImplTD float

template void index_select<ImplTD, ImplTI>(
        const ImplTD* __restrict__ const src_data,
        const ImplTI* __restrict__ const indices_data,
        ImplTD* __restrict__ const dst_data,
        size_t count,
        size_t group_size);

#undef ImplTD
#define ImplTD int64_t

template void index_select<ImplTD, ImplTI>(
        const ImplTD* __restrict__ const src_data,
        const ImplTI* __restrict__ const indices_data,
        ImplTD* __restrict__ const dst_data,
        size_t count,
        size_t group_size);

#undef ImplTD
#undef ImplTI

#define ImplProbDtype float
#define ImplLabelDtype int64_t
#define ImplBboxDtype float

template size_t roi_filter<ImplProbDtype, ImplLabelDtype, ImplBboxDtype, false>(
        const ImplProbDtype* __restrict__ const cls_prob_data_nc,
        ImplProbDtype* __restrict__ const scores_data,
        ImplLabelDtype* __restrict__ const labels_data,
        ImplBboxDtype* __restrict__ const bboxes_data_nb, // inplace
        size_t num_rois, size_t num_labels,
        const ImplProbDtype& score_threshold,
        const ImplBboxDtype& area_threshold,
        const ImplBboxDtype& xmin, const ImplBboxDtype& xmax,
        const ImplBboxDtype& ymin, const ImplBboxDtype& ymax);


template size_t roi_filter<ImplProbDtype, ImplLabelDtype, ImplBboxDtype, true>(
        const ImplProbDtype* __restrict__ const cls_prob_data_nc,
        ImplProbDtype* __restrict__ const scores_data,
        ImplLabelDtype* __restrict__ const labels_data,
        ImplBboxDtype* __restrict__ const bboxes_data_nb, // inplace
        size_t num_rois, size_t num_labels,
        const ImplProbDtype& score_threshold,
        const ImplBboxDtype& area_threshold,
        const ImplBboxDtype& xmin, const ImplBboxDtype& xmax,
        const ImplBboxDtype& ymin, const ImplBboxDtype& ymax);


template size_t roi_filter<ImplProbDtype, ImplLabelDtype, ImplBboxDtype, false>(
        const ImplProbDtype* __restrict__ const cls_prob_data_nc,
        ImplProbDtype* __restrict__ const scores_data,
        ImplLabelDtype* __restrict__ const labels_data,
        ImplBboxDtype* __restrict__ const bboxes_data_nb, // inplace
        ImplBboxDtype* __restrict__ const anchors_data_nb, // inplace
        size_t num_rois, size_t num_labels,
        const ImplProbDtype& score_threshold,
        const ImplBboxDtype& area_threshold,
        const ImplBboxDtype& xmin, const ImplBboxDtype& xmax,
        const ImplBboxDtype& ymin, const ImplBboxDtype& ymax);


template size_t roi_filter<ImplProbDtype, ImplLabelDtype, ImplBboxDtype, true>(
        const ImplProbDtype* __restrict__ const cls_prob_data_nc,
        ImplProbDtype* __restrict__ const scores_data,
        ImplLabelDtype* __restrict__ const labels_data,
        ImplBboxDtype* __restrict__ const bboxes_data_nb, // inplace
        ImplBboxDtype* __restrict__ const anchors_data_nb, // inplace
        size_t num_rois, size_t num_labels,
        const ImplProbDtype& score_threshold,
        const ImplBboxDtype& area_threshold,
        const ImplBboxDtype& xmin, const ImplBboxDtype& xmax,
        const ImplBboxDtype& ymin, const ImplBboxDtype& ymax);

#undef ImplProbDtype
#undef ImplLabelDtype

template void bbox_xywh2xyxy<ImplBboxDtype>(
        ImplBboxDtype* __restrict__ const bboxes_data_nb, // inplace, rel xywh form -> abs xyxy form
        size_t num_rois,
        const ImplBboxDtype& extra);

template void bbox_decode<ImplBboxDtype>(
        ImplBboxDtype* __restrict__ const bboxes_data_nb, // rel xywh form -> abs xyxy form
        const ImplBboxDtype* __restrict__ const anchors_data_nb,
        size_t size,
        const ImplBboxDtype& rweight_cx, const ImplBboxDtype& rweight_cy,
        const ImplBboxDtype& rweight_width, const ImplBboxDtype& rweight_height,
        const ImplBboxDtype& extra);

#define ImplKeypointDtype float

template void keypoint_postprocess<ImplKeypointDtype, ImplBboxDtype>(
        ImplKeypointDtype* __restrict__ const keypoints_data_np, // rel xyxy form -> abs xyxy form
        const ImplBboxDtype* __restrict__ const bboxes_data_nb,
        size_t size, size_t num_keypoints,
        const ImplBboxDtype& rweight_x, const ImplBboxDtype& rweight_y);

#undef ImplKeypointDtype
#undef ImplBboxDtype

} //namespace marker
} // namespace vp
