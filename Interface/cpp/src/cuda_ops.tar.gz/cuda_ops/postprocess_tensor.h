
#pragma once

#include <cstddef>
#include <limits>

#include "framework/tensor.h"

namespace vp
{
namespace marker
{

// index_select on dim 0, tensor version
template <typename TD, typename TI>
void index_select(
        const paddle_mobile::framework::Tensor& src_tensor, // N...
        const paddle_mobile::framework::Tensor& indices_tensor, // M
        paddle_mobile::framework::Tensor& dst_tensor); // M...

// roi_filter, tensor + inplace version
template <typename ProbDtype, typename LabelDtype, typename BboxDtype,
          bool B8TO4 = false>
size_t roi_filter(
        const paddle_mobile::framework::Tensor& cls_prob_tensor, // NC
        paddle_mobile::framework::Tensor& scores_tensor, // N
        paddle_mobile::framework::Tensor& labels_tensor, // N
        paddle_mobile::framework::Tensor& bboxes_tensor, // NB, inplace
        const ProbDtype& score_threshold = ProbDtype(0),
        const BboxDtype& area_threshold = BboxDtype(0),
        const BboxDtype& xmin = std::numeric_limits<BboxDtype>::lowest(),
        const BboxDtype& xmax = std::numeric_limits<BboxDtype>::max(),
        const BboxDtype& ymin = std::numeric_limits<BboxDtype>::lowest(),
        const BboxDtype& ymax = std::numeric_limits<BboxDtype>::max());

// roi_filter, with anchors, tensor + inplace version
template <typename ProbDtype, typename LabelDtype, typename BboxDtype,
          bool B8TO4 = false>
size_t roi_filter(
        const paddle_mobile::framework::Tensor& cls_prob_tensor, // NC
        paddle_mobile::framework::Tensor& scores_tensor, // N
        paddle_mobile::framework::Tensor& labels_tensor, // N
        paddle_mobile::framework::Tensor& bboxes_tensor, // NB, inplace
        paddle_mobile::framework::Tensor& anchors_tensor, // NB, inplace
        const ProbDtype& score_threshold = ProbDtype(0),
        const BboxDtype& area_threshold = BboxDtype(0),
        const BboxDtype& xmin = std::numeric_limits<BboxDtype>::lowest(),
        const BboxDtype& xmax = std::numeric_limits<BboxDtype>::max(),
        const BboxDtype& ymin = std::numeric_limits<BboxDtype>::lowest(),
        const BboxDtype& ymax = std::numeric_limits<BboxDtype>::max());

// bbox_xywh2xyxy, tensor + inplace version
template <typename BboxDtype>
void bbox_xywh2xyxy(paddle_mobile::framework::Tensor& bboxes_tensor); // NB, inplace

// bbox_decode, tensor + inplace version
template <typename BboxDtype>
void bbox_decode(
        paddle_mobile::framework::Tensor& bboxes_tensor, // NB, inplace
        const paddle_mobile::framework::Tensor& anchors_tensor, // NB
        BboxDtype rweight_cx = BboxDtype(1. / 1.),
        BboxDtype rweight_cy = BboxDtype(1. / 1.),
        BboxDtype rweight_width = BboxDtype(1. / 1.),
        BboxDtype rweight_height = BboxDtype(1. / 1.));

// marker_postprocess, tensor + inplace version
template <typename KeypointDtype, typename BboxDtype>
void marker_postprocess(
        paddle_mobile::framework::Tensor& keypoints_tensor, // NP, inplace
        const paddle_mobile::framework::Tensor& bboxes_tensor, // NB
        BboxDtype rweight = BboxDtype(1. / 10.));

} //namespace marker
} // namespace vp
