
#pragma once

#include <cstddef>

namespace vp
{
namespace marker
{

// roi_align, raw version, in HWC layout
template <typename TF, typename TB>
void roi_align(
        const TF* __restrict__ const bottom_data_hwc,
        const TB* __restrict__ const bboxes_data_nb,
        TF* __restrict__ const top_data_nhwc,
        size_t height, size_t width, size_t num_channels,
        size_t pooled_height, size_t pooled_width,
        size_t sampling_ratio,
        const TB& spatial_scale,
        size_t num_rois,
        size_t num_threads = 1, size_t idx_thread = 0);

} //namespace marker
} // namespace vp
