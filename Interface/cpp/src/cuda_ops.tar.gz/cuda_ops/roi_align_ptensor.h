
#pragma once

#include <cstddef>

#include "io/paddle_inference_api.h"

namespace vp
{
namespace marker
{

// roi_align, tensor version, in HWC layout
template <typename FeatureDtype, typename BboxDtype>
void roi_align(
        const paddle_mobile::PaddleTensor& bottom_tensor, // HWC
        const paddle_mobile::PaddleTensor& bboxes_tensor, // NB
        paddle_mobile::PaddleTensor& top_tensor, // NHWC
        size_t pooled_height, size_t pooled_width,
        size_t sampling_ratio,
        const BboxDtype& spatial_scale,
        size_t num_threads = 1, size_t idx_thread = 0);

} //namespace marker
} // namespace vp
