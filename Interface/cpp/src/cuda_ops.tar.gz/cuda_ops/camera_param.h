#pragma once

#include <cmath>
#include <map>
#include <string>

#include <Eigen/Geometry>

#include "hardware_config.pb.h"

namespace baidu {
namespace idg {
namespace node {
namespace vpdps {

using real_t = double;
using Vector = Eigen::Matrix<real_t, Eigen::Dynamic, 1, Eigen::ColMajor, 16, 1>;
using Vector2 = Eigen::Matrix<real_t, 2, 1>;
using Vector3 = Eigen::Matrix<real_t, 3, 1>;
using Vector4 = Eigen::Matrix<real_t, 4, 1>;
using Matrix3x3 = Eigen::Matrix<real_t, 3, 3, Eigen::RowMajor>;
using Matrix4x4 = Eigen::Matrix<real_t, 4, 4, Eigen::RowMajor>;

struct CameraParam
{
    bool is_fisheye = false;             // is camera in fisheye model
    int32_t width = 0, height = 0;       // image pixel size
    real_t fx = 0, fy = 0;               // focal length (x, y) in pixel
    real_t cx = 0, cy = 0;               // optical center (x, y) in pixel
    real_t inv_k11 = 0, inv_k22 = 0;     // 1 / f
    real_t inv_k13 = 0, inv_k23 = 0;     // -c / f
    real_t yaw = 0, pitch = 0, roll = 0; // euler angle, rotation after translation, in radian
    Vector3 translation;                 // (x = front, y = left, z = up) from car in meter
    Vector dist_coeffs;                  // distortion coeffs, 5 for pinhole, 4 for fisheye

    /*
     * camera space coordinate:
     *
     *     ^ z
     *    /
     *   /
     *  /
     * O---------> x
     * |
     * |
     * |
     * v
     * y
     *
     * world space coordinate:
     *
     *             z
     *             ^    ^ x
     *             |   /
     *             |  /
     *             | /
     * y <---------O
     *
     */

    static inline Matrix3x3 camera_to_world_rotation()
    {
        Matrix3x3 ret;
        ret <<  0,  0, +1,
               -1,  0,  0,
                0, -1,  0;
        return ret;
    }

    static inline Matrix4x4 camera_to_world_transform()
    {
        Matrix4x4 ret;
        ret <<  0,  0, +1,  0,
               -1,  0,  0,  0,
                0, -1,  0,  0,
                0,  0,  0, +1;
        return ret;
    }

    static inline Matrix3x3 world_to_camera_rotation()
    {
        Matrix3x3 ret;
        ret <<  0, -1,  0,
                0,  0, -1,
               +1,  0,  0;
        return ret;
    }

    static inline Matrix4x4 world_to_camera_transform()
    {
        Matrix4x4 ret;
        ret <<  0, -1,  0,  0,
                0,  0, -1,  0,
               +1,  0,  0,  0,
                0,  0,  0, +1;
        return ret;
    }

    inline Matrix3x3 camera_matrix() const
    {
        Matrix3x3 ret;
        ret << fx,  0, cx,
                0, fy, cy,
                0,  0, +1;
        return ret;
    }

    // world space
    inline Matrix3x3 car_to_camera_rotation() const
    {
        real_t c1 = std::cos(roll);
        real_t s1 = std::sin(roll);
        Matrix3x3 m1;
        m1 <<  +1,   0,   0,
                0, +c1, -s1,
                0, +s1, +c1;
        real_t c2 = std::cos(yaw);
        real_t s2 = std::sin(yaw);
        Matrix3x3 m2;
        m2 << +c2, -s2,   0,
              +s2, +c2,   0,
                0,   0,  +1;
        real_t c3 = std::cos(pitch);
        real_t s3 = std::sin(pitch);
        Matrix3x3 m3;
        m3 << +c3,   0, +s3,
                0,  +1,   0,
              -s3,   0, +c3;
        return m3 * m2 * m1;
    }

    // world space
    inline Matrix3x3 camera_to_car_rotation() const
    {
        real_t c1 = std::cos(roll);
        real_t s1 = std::sin(roll);
        Matrix3x3 m1;
        m1 <<  +1,   0,   0,
                0, +c1, +s1,
                0, -s1, +c1;
        real_t c2 = std::cos(yaw);
        real_t s2 = std::sin(yaw);
        Matrix3x3 m2;
        m2 << +c2, +s2,   0,
              -s2, +c2,   0,
                0,   0,  +1;
        real_t c3 = std::cos(pitch);
        real_t s3 = std::sin(pitch);
        Matrix3x3 m3;
        m3 << +c3,   0, -s3,
                0,  +1,   0,
              +s3,   0, +c3;
        return m1 * m2 * m3;
    }

    inline void update_inv_k()
    {
        inv_k11 = 1 / fx;
        inv_k22 = 1 / fy;
        inv_k13 = -cx / fx;
        inv_k23 = -cy / fy;
    }

    inline Vector2 liftproject_without_distortion(const Vector2& p2d) const
    {
        real_t ux = inv_k11 * p2d[0] + inv_k13;
        real_t uy = inv_k22 * p2d[1] + inv_k23;

        Vector2 u2d;
        u2d << ux, uy;
        return u2d;
    }

    inline Vector2 distortion(const Vector2& u) const
    {
        real_t k1 = dist_coeffs[0];
        real_t k2 = dist_coeffs[1];
        real_t p1 = dist_coeffs[2];
        real_t p2 = dist_coeffs[3];

        real_t ux2 = u[0] * u[0];
        real_t uy2 = u[1] * u[1];
        real_t uxy = u[0] * u[1];
        real_t rho2 = ux2 + uy2;
        real_t rad_dist = k1 * rho2 + k2 * rho2 * rho2;

        Vector2 d;
        d <<    u[0] * rad_dist + 2 * p1 * uxy + p2 * (rho2 + 2 * ux2),
                u[1] * rad_dist + 2 * p2 * uxy + p1 * (rho2 + 2 * uy2);
        return d;
    }

    inline Vector2 liftproject(const Vector2& p2d, int num_iters=8) const
    {
        real_t ux = inv_k11 * p2d[0] + inv_k13;
        real_t uy = inv_k22 * p2d[1] + inv_k23;
        Vector2 u { ux, uy }, d = u;

        if (num_iters > 0)
        {
            // Recursive distortion model
            while (num_iters-- > 0)
            {
                d = u - distortion(d);
            }
        }
        else
        {
            // Apply inverse distortion model
            // proposed by Heikkila

            real_t k1 = dist_coeffs[0];
            real_t k2 = dist_coeffs[1];
            real_t p1 = dist_coeffs[2];
            real_t p2 = dist_coeffs[3];

            real_t ux2 = u[0] * u[0];
            real_t uy2 = u[1] * u[1];
            real_t uxy = u[0] * u[1];
            real_t rho2 = ux2 + uy2;
            real_t rho4 = rho2 * rho2;
            real_t rad_dist = k1 * rho2 + k2 * rho4;
            real_t dx = ux * rad_dist + p2 * (rho2 + 2 * ux2) + 2 * p1 * uxy;
            real_t dy = uy * rad_dist + p1 * (rho2 + 2 * uy2) + 2 * p2 * uxy;
            real_t inv_denom = 1 / (1 +
                                    4 * k1 * rho2 +
                                    6 * k2 * rho4 +
                                    8 * (p1 * uy + p2 * ux)
                                    );

            d = u - inv_denom * Vector2 { dx, dy };
        }

        Vector2 u2d;
        u2d << d[0], d[1];
        return u2d;
    }

};

class CameraParams
{
public:
    CameraParams(const std::string& config_path);
    CameraParams(const CameraParams& other) = default;
    CameraParams(CameraParams&& other) = default;
    ~CameraParams(); // = default;

    CameraParams& operator=(const CameraParams& other) = default;
    CameraParams& operator=(CameraParams&& other) = default;

public:
    using CameraName = ::autopilot_hardware::CameraParameter_CameraNameType; // enum type

    bool inited() const;
    const CameraParam* get(CameraName name) const;

//    const CameraParam* get(CameraName name);
    bool load(const std::string& config_path, real_t scale=1);
protected:
    bool _inited = false;

    std::map<CameraName, CameraParam> _data;

};

} // namespace vpdps
} // namespace node
} // namespace idg
} // namespace baidu
