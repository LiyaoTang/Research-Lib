
#include "roi_align_tensor.h"

#include <cassert>

#include "roi_align.h"

namespace frw = paddle_mobile::framework;

namespace vp
{
namespace marker
{

// roi_align, tensor version, in HWC layout
template <typename FeatureDtype, typename BboxDtype>
void roi_align(
        const frw::Tensor& bottom_tensor, // HWC
        const frw::Tensor& bboxes_tensor, // NB
        frw::Tensor& top_tensor, // NHWC
        size_t pooled_height, size_t pooled_width,
        size_t sampling_ratio,
        const BboxDtype& spatial_scale,
        size_t num_threads, size_t idx_thread)
{
    auto inp_dims = bottom_tensor.dims();

    if (inp_dims.size() == 4)
    {
        assert(inp_dims[0] == 1); // 1HWC
        inp_dims = frw::make_ddim({ inp_dims[1], inp_dims[2], inp_dims[3] });
    }

    assert(bottom_tensor.layout == frw::LAYOUT_HWC);
    assert(inp_dims.size() == 3); // HWC
    assert(bboxes_tensor.dims().size() == 2); // NB
    assert(bboxes_tensor.dims()[1] == 4); // N * 4

    const auto height = inp_dims[0];
    const auto width = inp_dims[1];
    const auto num_channels = inp_dims[2];
    const auto num_rois = bboxes_tensor.dims()[0];
    const auto bottom_data_hwc = bottom_tensor.data<FeatureDtype>();
    const auto bboxes_data_nb = bboxes_tensor.data<BboxDtype>();

    auto out_dims = frw::DDim(frw::Dim<4>());
    out_dims[0] = num_rois;
    out_dims[1] = int(pooled_height);
    out_dims[2] = int(pooled_width);
    out_dims[3] = num_channels;
    auto top_data_nhwc = top_tensor.mutable_data<FeatureDtype>(out_dims);

    roi_align(bottom_data_hwc, bboxes_data_nb,
              top_data_nhwc,
              size_t(height), size_t(width), size_t(num_channels),
              pooled_height, pooled_width,
              sampling_ratio,
              spatial_scale,
              size_t(num_rois),
              num_threads, idx_thread);
}


#define ImplFeatureDtype float
#define ImplBboxDtype float

template void roi_align<ImplFeatureDtype, ImplBboxDtype>(
        const frw::Tensor& bottom_tensor, // HWC
        const frw::Tensor& bboxes_tensor, // NB
        frw::Tensor& top_tensor, // NHWC
        size_t pooled_height, size_t pooled_width,
        size_t sampling_ratio,
        const ImplBboxDtype& spatial_scale,
        size_t num_threads, size_t idx_thread);

#undef ImplBboxDtype
#undef ImplFeatureDtype

} //namespace marker
} // namespace vp
