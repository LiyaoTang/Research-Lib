
#pragma once

#include <cstddef>
#include <limits>

#include "framework/tensor.h"

namespace vp
{
namespace marker
{

// nms, tensor version, output indices
template <typename BboxDtype,
          typename IndexDtype = void, typename IouType = float>
auto nms(
        const paddle_mobile::framework::Tensor& bboxes_tensor, // NB
        paddle_mobile::framework::Tensor& out_tensor, // N
        const IouType& threshold,
        size_t top_k = std::numeric_limits<size_t>::max())
    -> typename std::enable_if<!std::is_same<IndexDtype, void>::value, size_t>::type;

// nms, tensor version, output bboxes
template <typename BboxDtype,
          typename IndexDtype = void, typename IouType = float>
auto nms(
        const paddle_mobile::framework::Tensor& bboxes_tensor, // NB
        paddle_mobile::framework::Tensor& out_tensor, // NB
        const IouType& threshold,
        size_t top_k = std::numeric_limits<size_t>::max())
    -> typename std::enable_if<std::is_same<IndexDtype, void>::value, size_t>::type;

// nms_unordered, tensor version, output indices
template <typename BboxDtype, typename ScoreDtype,
          typename IndexDtype = void, typename IouType = float>
auto nms(
        const paddle_mobile::framework::Tensor& bboxes_tensor, // NB
        const paddle_mobile::framework::Tensor& scores_tensor, // N
        paddle_mobile::framework::Tensor& out_tensor, // N
        const IouType& threshold,
        size_t top_k = std::numeric_limits<size_t>::max())
    -> typename std::enable_if<!std::is_same<IndexDtype, void>::value, size_t>::type;

// nms_unordered, tensor version, output bboxes
template <typename BboxDtype, typename ScoreDtype,
          typename IndexDtype = void, typename IouType = float>
auto nms(
        const paddle_mobile::framework::Tensor& bboxes_tensor, // NB
        const paddle_mobile::framework::Tensor& scores_tensor, // N
        paddle_mobile::framework::Tensor& out_tensor, // NB
        const IouType& threshold,
        size_t top_k = std::numeric_limits<size_t>::max())
    -> typename std::enable_if<std::is_same<IndexDtype, void>::value, size_t>::type;

} //namespace marker
} // namespace vp
