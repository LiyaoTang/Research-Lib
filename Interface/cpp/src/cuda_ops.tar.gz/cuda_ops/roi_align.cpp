
#include "roi_align.h"

#include <algorithm>
#include <cassert>
#include <cmath>

namespace vp
{
namespace marker
{

// roi_align_single_roi, raw version, in HWC layout
template <typename TF, typename TI>
static void roi_align_single_roi(
        const TF* __restrict__ const bottom_data_hwc,
        TF* __restrict__ const top_data_hwc,
        size_t height, size_t width, size_t num_channels,
        size_t pooled_height, size_t pooled_width,
        size_t roi_bin_grid_h, size_t roi_bin_grid_w,
        const TI& roi_start_h, const TI& roi_start_w,
        const TI& bin_size_h, const TI& bin_size_w)
{
    const auto roi_bin_grid_h_ = TI(roi_bin_grid_h);
    const auto roi_bin_grid_w_ = TI(roi_bin_grid_w);
    const auto count_ = roi_bin_grid_h_ * roi_bin_grid_w_; // use expected grid size
    for (size_t ph = 0; ph < pooled_height; ++ph)
    {
        const auto ry = roi_start_h + TI(ph) * bin_size_h;
        for (size_t pw = 0; pw < pooled_width; ++pw)
        {
            const auto rx = roi_start_w + TI(pw) * bin_size_w;
            const auto top_data_c = top_data_hwc + (ph * pooled_width + pw) * num_channels;
            std::fill_n(top_data_c, num_channels, TF(0));

//            size_t count = 0; // use real counted size

#pragma omp for
            for (size_t iy = 0; iy < roi_bin_grid_h; ++iy)
            {
                const auto yy = ry + TI(iy + .5) * bin_size_h / roi_bin_grid_h_;
                for (size_t ix = 0; ix < roi_bin_grid_w; ++ix)
                {
                    const auto xx = rx + TI(ix + .5) * bin_size_w / roi_bin_grid_w_;

                    auto x = xx;
                    auto y = yy;

                    // deal with: inverse elements are out of feature map boundary
                    if (y <= TI(-1) || y >= TI(height) ||
                        x <= TI(-1) || x >= TI(width))
                    {
                        continue;
                    }

                    if (y < TI(0))
                    {
                        y = TI(0);
                    }

                    if (x < TI(0))
                    {
                        x = TI(0);
                    }

                    size_t y_low = size_t(y), x_low = size_t(x);
                    size_t y_high, x_high;

                    if (y_low >= height - 1)
                    {
                        y_high = y_low = height - 1;
                        y = TI(y_low);
                    }
                    else
                    {
                        y_high = y_low + 1;
                    }

                    if (x_low >= width - 1)
                    {
                        x_high = x_low = width - 1;
                        x = TI(x_low);
                    }
                    else
                    {
                        x_high = x_low + 1;
                    }

                    const auto ly = y - TI(y_low);
                    const auto lx = x - TI(x_low);
                    const auto hy = TI(1) - ly;
                    const auto hx = TI(1) - lx;

                    const auto o1 = (y_low * width + x_low) * num_channels;
                    const auto o2 = (y_low * width + x_high) * num_channels;
                    const auto o3 = (y_high * width + x_low) * num_channels;
                    const auto o4 = (y_high * width + x_high) * num_channels;
                    const auto w1 = hy * hx;
                    const auto w2 = hy * lx;
                    const auto w3 = ly * hx;
                    const auto w4 = ly * lx;

#pragma omp simd
                    for (size_t pc = 0; pc < num_channels; ++pc)
                    {
                        top_data_c[pc] += w1 * bottom_data_hwc[o1 + pc];
                        top_data_c[pc] += w2 * bottom_data_hwc[o2 + pc];
                        top_data_c[pc] += w3 * bottom_data_hwc[o3 + pc];
                        top_data_c[pc] += w4 * bottom_data_hwc[o4 + pc];
                    }

//                    ++count;
                }
            }

#pragma omp simd
            for (size_t pc = 0; pc < num_channels; ++pc)
            {
                top_data_c[pc] /= count_;
            }

//            // HINT: impl differs, real count or expected count?
//            if (count > 0)
//            {
//                const auto count_ = TI(count);
//
//#pragma omp simd
//                for (size_t pc = 0; pc < num_channels; ++pc)
//                {
//                    top_data_c[pc] /= count_;
//                }
//            }
        }
    }
}

// roi_align, raw version, in HWC layout
template <typename TF, typename TB>
void roi_align(
        const TF* __restrict__ const bottom_data_hwc,
        const TB* __restrict__ const bboxes_data_nb,
        TF* __restrict__ const top_data_nhwc,
        size_t height, size_t width, size_t num_channels,
        size_t pooled_height, size_t pooled_width,
        size_t sampling_ratio,
        const TB& spatial_scale,
        size_t num_rois,
        size_t num_threads, size_t idx_thread)
{
    assert(height > 0);
    assert(width > 0);
    assert(pooled_height > 0);
    assert(pooled_width > 0);
    assert(spatial_scale > 0);

    const auto pooled_height_ = TB(pooled_height);
    const auto pooled_width_ = TB(pooled_width);

    const size_t start_roi = idx_thread * num_rois / num_threads;
    const size_t end_roi = (idx_thread + 1) * num_rois / num_threads;

#pragma omp for
//#pragma omp parallel for num_threads(4)
    for (size_t idx_roi = start_roi; idx_roi < end_roi; ++idx_roi)
    {
        const auto bbox = bboxes_data_nb + idx_roi * 4;

        const auto roi_start_w = bbox[0] * spatial_scale;
        const auto roi_start_h = bbox[1] * spatial_scale;
        const auto roi_end_w = bbox[2] * spatial_scale;
        const auto roi_end_h = bbox[3] * spatial_scale;

        // Force malformed ROIs to be 1x1
        const auto roi_height = std::max(TB(1), roi_end_h - roi_start_h);
        const auto roi_width = std::max(TB(1), roi_end_w - roi_start_w);
        const auto bin_size_h = roi_height / pooled_height_;
        const auto bin_size_w = roi_width / pooled_width_;

        // We use roi_bin_grid to sample the grid and mimic integral
        const size_t roi_bin_grid_h = (sampling_ratio > 0) ?
                    sampling_ratio : std::ceil(bin_size_h);
        const size_t roi_bin_grid_w = (sampling_ratio > 0) ?
                    sampling_ratio : std::ceil(bin_size_w);

        roi_align_single_roi(
            bottom_data_hwc,
            top_data_nhwc + idx_roi * pooled_height * pooled_width * num_channels,
            height, width, num_channels,
            pooled_height, pooled_width,
            roi_bin_grid_h, roi_bin_grid_w,
            roi_start_h, roi_start_w,
            bin_size_h, bin_size_w);
    }
}


#define ImplFeatureDtype float
#define ImplBboxDtype float

template void roi_align<ImplFeatureDtype, ImplBboxDtype>(
        const ImplFeatureDtype* __restrict__ const bottom_data_hwc,
        const ImplBboxDtype* __restrict__ const bboxes_data_nb,
        ImplFeatureDtype* __restrict__ const top_data_nhwc,
        size_t height, size_t width, size_t num_channels,
        size_t pooled_height, size_t pooled_width,
        size_t sampling_ratio,
        const ImplBboxDtype& spatial_scale,
        size_t num_rois,
        size_t num_threads, size_t idx_thread);

#undef ImplBboxDtype
#undef ImplFeatureDtype

} //namespace marker
} // namespace vp
