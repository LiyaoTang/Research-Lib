
#include "nms_kernel_cpu.h"

#include "nms_tensor.h"

namespace vp
{
namespace marker
{

template <typename DeviceType, typename BboxDtype, typename IndexDtype>
void NmsKernel<DeviceType, BboxDtype, IndexDtype>::Compute(
        const NmsParam& param)
{
    const auto output_bboxes = param.OutputBboxes();
    const auto bboxes_tensor = param.Bboxes();
    const auto threshold = param.Threshold();
    const auto top_k = param.TopK();

    if (!output_bboxes)
    {
        nms<BboxDtype, IndexDtype>(
                    *bboxes_tensor,
                    *param.OutIndices(),
                    threshold,
                    top_k);
    }
    else
    {
        nms<BboxDtype>(
                    *bboxes_tensor,
                    *param.OutBboxes(),
                    threshold,
                    top_k);
    }
}

template <typename DeviceType, typename BboxDtype, typename ScoreDtype, typename IndexDtype>
void NmsUnorderedKernel<DeviceType, BboxDtype, ScoreDtype, IndexDtype>::Compute(
        const NmsUnorderedParam& param)
{
    const auto output_bboxes = param.OutputBboxes();
    const auto bboxes_tensor = param.Bboxes();
    const auto scores_tensor = param.Scores();
    const auto threshold = param.Threshold();
    const auto top_k = param.TopK();

    if (!output_bboxes)
    {
        nms<BboxDtype, ScoreDtype, IndexDtype>(
                    *bboxes_tensor, *scores_tensor,
                    *param.OutIndices(),
                    threshold,
                    top_k);
    }
    else
    {
        nms<BboxDtype, ScoreDtype>(
                    *bboxes_tensor, *scores_tensor,
                    *param.OutBboxes(),
                    threshold,
                    top_k);
    }
}

#define ImplBboxDtype float
#define ImplIndexDtype int64_t

template void NmsKernel<paddle_mobile::CPU, ImplBboxDtype, ImplIndexDtype>::Compute(
        const NmsParam& param);

#define ImplScoreDtype float

template void NmsUnorderedKernel<paddle_mobile::CPU, ImplBboxDtype,
                                 ImplScoreDtype, ImplIndexDtype>::Compute(
        const NmsUnorderedParam& param);

#undef ImplIndexDtype
#undef ImplScoreDtype
#undef ImplBboxDtype

} //namespace marker
} // namespace vp
