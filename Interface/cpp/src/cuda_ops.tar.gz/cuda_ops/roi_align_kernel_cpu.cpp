
#include "roi_align_kernel_cpu.h"

#include "roi_align_tensor.h"

namespace vp
{
namespace marker
{

template <typename DeviceType, typename FeatureDtype, typename BboxDtype>
void RoiAlignKernel<DeviceType, FeatureDtype, BboxDtype>::Compute(
        const RoiAlignParam<BboxDtype>& param)
{
    const auto pooled_height = param.PooledHeight();
    const auto pooled_width = param.PooledWidth();
    const auto sampling_ratio = param.SamplingRatio();
    const auto spatial_scale = param.SpatialScale();
    const auto bottom_tensor = param.Feature();
    const auto bboxes_tensor = param.Bboxes();

    auto top_tensor = param.OutFeatures();

    roi_align<FeatureDtype, BboxDtype>(
                *bottom_tensor, *bboxes_tensor,
                *top_tensor,
                pooled_height, pooled_width,
                sampling_ratio,
                spatial_scale);
}


#define ImplFeatureDtype float
#define ImplBboxDtype float

template void RoiAlignKernel<paddle_mobile::CPU, ImplFeatureDtype, ImplBboxDtype>::Compute(
        const RoiAlignParam<ImplBboxDtype>& param);

#undef ImplBboxDtype
#undef ImplFeatureDtype

} //namespace marker
} // namespace vp
