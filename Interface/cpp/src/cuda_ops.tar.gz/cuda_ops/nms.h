
#pragma once

#include <cstddef>
#include <limits>

namespace vp
{
namespace marker
{

// nms, raw version, output indices
template <typename TB, typename TI,
          typename TR = float>
size_t nms_index(
        const TB* __restrict__ const bboxes_data_nb,
        TI* __restrict__ const out_indices_data,
        TB* __restrict__ const areas_data,
        size_t num_rois,
        const TR& threshold,
        size_t top_k = std::numeric_limits<size_t>::max());

// nms_unordered, raw version, output indices
template <typename TB, typename TS,  typename TI,
          typename TR = float>
size_t nms_index(
        const TB* __restrict__ const bboxes_data_nb, const TS* __restrict__ const scores_data,
        TI* __restrict__ const out_indices_data,
        TB* __restrict__ const areas_data,
        size_t num_rois,
        const TR& threshold,
        size_t top_k = std::numeric_limits<size_t>::max());

// nms, raw version, output bboxes
template <typename TB,
          typename TR = float>
size_t nms_bbox(
        const TB* __restrict__ const bboxes_data_nb,
        TB* __restrict__ const out_bboxes_data_nb,
        size_t* __restrict__ const indices_data, TB* __restrict__ const areas_data,
        size_t num_rois,
        const TR& threshold,
        size_t top_k = std::numeric_limits<size_t>::max());

// nms_unordered, raw version, output bboxes
template <typename TB, typename TS,
          typename TR = float>
size_t nms_bbox(
        const TB* __restrict__ const bboxes_data_nb, const TS* __restrict__ const scores_data,
        TB* __restrict__ const out_bboxes_data_nb,
        size_t* __restrict__ const indices_data, TB* __restrict__ const areas_data,
        size_t num_rois,
        const TR& threshold,
        size_t top_k = std::numeric_limits<size_t>::max());

} //namespace marker
} // namespace vp
