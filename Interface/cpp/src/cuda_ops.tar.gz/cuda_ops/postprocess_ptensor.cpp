
#include "postprocess_ptensor.h"

#include <cassert>
#include <numeric>

#include "postprocess.h"

using paddle_mobile::PaddleTensor;
using PaddleShape = std::vector<int>;

namespace vp
{
namespace marker
{

template <typename Dtype>
static const Dtype* _data(const PaddleTensor& tensor)
{
    return reinterpret_cast<const Dtype*>(tensor.data.data());
}

template <typename Dtype>
static Dtype* _data(PaddleTensor& tensor)
{
    return reinterpret_cast<Dtype*>(tensor.data.data());
}

template <typename Dtype>
static Dtype* _mutable_data(PaddleTensor& tensor, const PaddleShape& shape)
{
    assert(!shape.empty() && shape[0] >= 0);
    const auto numel = size_t(std::accumulate(shape.cbegin(), shape.cend(),
                                              1, std::multiplies<PaddleShape::value_type>()));
    tensor.data.Resize(numel * sizeof(Dtype));
    tensor.shape = shape;
    return reinterpret_cast<Dtype*>(tensor.data.data());
}

// index_select on dim 0, tensor version
template <typename TD, typename TI>
void index_select(
        const PaddleTensor& src_tensor, // N...
        const PaddleTensor& indices_tensor, // M
        PaddleTensor& dst_tensor) // M...
{
    assert(src_tensor.shape.size() >= 1); // N...
    assert(indices_tensor.shape.size() == 1); // M

    const auto src_data = _data<TD>(src_tensor);
    const auto indices_data = _data<TI>(indices_tensor);

    const auto count = indices_tensor.shape[0];
    const auto group_size = size_t(
                std::accumulate(src_tensor.shape.cbegin() + 1, src_tensor.shape.cend(),
                                1, std::multiplies<PaddleShape::value_type>()));

    auto out_dims = src_tensor.shape;
    out_dims[0] = count;

    auto dst_data = _mutable_data<TD>(dst_tensor, out_dims);

    index_select(src_data, indices_data, dst_data,
                 size_t(count),
                 size_t(group_size));
}

// roi_filter, tensor + inplace version
template <typename ProbDtype, typename LabelDtype, typename BboxDtype,
          bool B8TO4>
size_t roi_filter(
        const PaddleTensor& cls_prob_tensor, // NC
        PaddleTensor& scores_tensor, // N
        PaddleTensor& labels_tensor, // N
        PaddleTensor& bboxes_tensor, // NB, inplace
        const ProbDtype& score_threshold,
        const BboxDtype& area_threshold,
        const BboxDtype& xmin, const BboxDtype& xmax,
        const BboxDtype& ymin, const BboxDtype& ymax)
{
    assert(cls_prob_tensor.shape.size() == 2); // NC
    assert(bboxes_tensor.shape.size() == 2); // NB
    assert(bboxes_tensor.shape[1] == (B8TO4 ? 8 : 4)); // N * (4 or 8)

    const auto num_rois = cls_prob_tensor.shape[0];
    const auto num_labels = cls_prob_tensor.shape[1];
    const auto cls_prob_data = _data<ProbDtype>(cls_prob_tensor);

    assert(num_rois == bboxes_tensor.shape[0]); // N == N

    auto scores_data = _mutable_data<ProbDtype>(scores_tensor, { num_rois });
    auto labels_data = _mutable_data<LabelDtype>(labels_tensor, { num_rois });
    auto bboxes_data_nb = _data<BboxDtype>(bboxes_tensor);

    const auto num_filterd = roi_filter<ProbDtype, LabelDtype, BboxDtype, B8TO4>(
                cls_prob_data,
                scores_data,
                labels_data,
                bboxes_data_nb,
                size_t(num_rois), size_t(num_labels),
                score_threshold,
                area_threshold,
                xmin, xmax,
                ymin, ymax);

    scores_tensor.shape[0] = num_filterd;
    labels_tensor.shape[0] = num_filterd;
    bboxes_tensor.shape[0] = num_filterd;
    bboxes_tensor.shape[1] = 4; // ensured to be 4
    return num_filterd;
}

// roi_filter, with anchors, tensor + inplace version
template <typename ProbDtype, typename LabelDtype, typename BboxDtype,
          bool B8TO4>
size_t roi_filter(
        const PaddleTensor& cls_prob_tensor, // NC
        PaddleTensor& scores_tensor, // N
        PaddleTensor& labels_tensor, // N
        PaddleTensor& bboxes_tensor, // NB, inplace
        PaddleTensor& anchors_tensor, // NB, inplace
        const ProbDtype& score_threshold,
        const BboxDtype& area_threshold,
        const BboxDtype& xmin, const BboxDtype& xmax,
        const BboxDtype& ymin, const BboxDtype& ymax)
{
    assert(cls_prob_tensor.shape.size() == 2); // NC
    assert(bboxes_tensor.shape.size() == 2); // NB
    assert(bboxes_tensor.shape[1] == (B8TO4 ? 8 : 4)); // N * (4 or 8)
    assert(anchors_tensor.shape.size() == 2); // NB
    assert(anchors_tensor.shape[1] == 4); // N * 4

    const auto num_rois = cls_prob_tensor.shape[0];
    const auto num_labels = cls_prob_tensor.shape[1];
    const auto cls_prob_data = _data<ProbDtype>(cls_prob_tensor);

    assert(num_rois == bboxes_tensor.shape[0]); // N == N
    assert(num_rois == anchors_tensor.shape[0]); // N == N

    auto scores_data = _mutable_data<ProbDtype>(scores_tensor, { num_rois });
    auto labels_data = _mutable_data<LabelDtype>(labels_tensor, { num_rois });
    auto bboxes_data_nb = _data<BboxDtype>(bboxes_tensor);
    auto anchors_data_nb = _data<BboxDtype>(anchors_tensor);

    const auto num_filterd = roi_filter<ProbDtype, LabelDtype, BboxDtype, B8TO4>(
                cls_prob_data,
                scores_data,
                labels_data,
                bboxes_data_nb,
                anchors_data_nb,
                size_t(num_rois), size_t(num_labels),
                score_threshold,
                area_threshold,
                xmin, xmax,
                ymin, ymax);

    scores_tensor.shape[0] = num_filterd;
    labels_tensor.shape[0] = num_filterd;
    bboxes_tensor.shape[0] = num_filterd;
    bboxes_tensor.shape[1] = 4; // ensured to be 4
    anchors_tensor.shape[0] = num_filterd;
    return num_filterd;
}

// bbox_xywh2xyxy, tensor + inplace version
template <typename BboxDtype>
void bbox_xywh2xyxy(PaddleTensor& bboxes_tensor) // NB
{
    assert(bboxes_tensor.shape.size() == 2); // NB
    assert(bboxes_tensor.shape[1] == 4); // N * 4

    const auto num_rois = bboxes_tensor.shape[0];

    auto bboxes_data_nb = _data<BboxDtype>(bboxes_tensor);

    bbox_xywh2xyxy(bboxes_data_nb,
                   size_t(num_rois));
}

// bbox_decode, tensor + inplace version
template <typename BboxDtype>
void bbox_decode(
        PaddleTensor& bboxes_tensor, // NB, inplace
        const PaddleTensor& anchors_tensor, // NB
        BboxDtype rweight_cx, BboxDtype rweight_cy,
        BboxDtype rweight_width, BboxDtype rweight_height)
{
    assert(bboxes_tensor.shape.size() == 2); // NB
    assert(bboxes_tensor.shape[1] == 4); // N * 4
    assert(anchors_tensor.shape.size() == 2); // NB
    assert(anchors_tensor.shape[1] == 4); // N * 4

    const auto num_rois = bboxes_tensor.shape[0];

    assert(num_rois == anchors_tensor.shape[0]); // N == N

    const auto anchors_data_nb = _data<BboxDtype>(anchors_tensor);

    auto bboxes_data_nb = _data<BboxDtype>(bboxes_tensor);

    bbox_decode(bboxes_data_nb,
                anchors_data_nb,
                size_t(num_rois),
                rweight_cx, rweight_cy,
                rweight_width, rweight_height);
}

// marker_postprocess, tensor + inplace version
template <typename KeypointDtype, typename BboxDtype>
void marker_postprocess(
        PaddleTensor& keypoints_tensor, // NP, inplace
        const PaddleTensor& bboxes_tensor, // NB
        BboxDtype rweight)
{
    const size_t num_keypoints = 4;

    assert(keypoints_tensor.shape.size() == 2); // NP
    assert(keypoints_tensor.shape[1] == num_keypoints * 2); // N * (P * 2)
    assert(bboxes_tensor.shape.size() == 2); // NB
    assert(bboxes_tensor.shape[1] == 4); // N * 4

    const auto num_rois = keypoints_tensor.shape[0];

    assert(num_rois == bboxes_tensor.shape[0]); // N == N

    const auto bboxes_data_nb = _data<BboxDtype>(bboxes_tensor);

    auto keypoints_data_np = _data<KeypointDtype>(keypoints_tensor);

    keypoint_postprocess(
                keypoints_data_np,
                bboxes_data_nb,
                size_t(num_rois), num_keypoints,
                rweight, rweight);
}


#define ImplTI int64_t
#define ImplTD float

template void index_select<ImplTD, ImplTI>(
        const PaddleTensor& src_tensor, // N...
        const PaddleTensor& indices_tensor, // M
        PaddleTensor& dst_tensor);

#undef ImplTD
#define ImplTD int64_t

template void index_select<ImplTD, ImplTI>(
        const PaddleTensor& src_tensor, // N...
        const PaddleTensor& indices_tensor, // M
        PaddleTensor& dst_tensor);

#undef ImplTD
#undef ImplTI

#define ImplProbDtype float
#define ImplLabelDtype int64_t
#define ImplBboxDtype float

template size_t roi_filter<ImplProbDtype, ImplLabelDtype, ImplBboxDtype, false>(
        const PaddleTensor& cls_prob_tensor, // NC
        PaddleTensor& scores_tensor, // N
        PaddleTensor& labels_tensor, // N
        PaddleTensor& bboxes_tensor, // NB, inplace
        const ImplProbDtype& score_threshold,
        const ImplBboxDtype& area_threshold,
        const ImplBboxDtype& xmin, const ImplBboxDtype& xmax,
        const ImplBboxDtype& ymin, const ImplBboxDtype& ymax);

template size_t roi_filter<ImplProbDtype, ImplLabelDtype, ImplBboxDtype, true>(
        const PaddleTensor& cls_prob_tensor, // NC
        PaddleTensor& scores_tensor, // N
        PaddleTensor& labels_tensor, // N
        PaddleTensor& bboxes_tensor, // NB, inplace
        const ImplProbDtype& score_threshold,
        const ImplBboxDtype& area_threshold,
        const ImplBboxDtype& xmin, const ImplBboxDtype& xmax,
        const ImplBboxDtype& ymin, const ImplBboxDtype& ymax);

template size_t roi_filter<ImplProbDtype, ImplLabelDtype, ImplBboxDtype, false>(
        const PaddleTensor& cls_prob_tensor, // NC
        PaddleTensor& scores_tensor, // N
        PaddleTensor& labels_tensor, // N
        PaddleTensor& bboxes_tensor, // NB, inplace
        PaddleTensor& anchors_tensor, // NB, inplace
        const ImplProbDtype& score_threshold,
        const ImplBboxDtype& area_threshold,
        const ImplBboxDtype& xmin, const ImplBboxDtype& xmax,
        const ImplBboxDtype& ymin, const ImplBboxDtype& ymax);

template size_t roi_filter<ImplProbDtype, ImplLabelDtype, ImplBboxDtype, true>(
        const PaddleTensor& cls_prob_tensor, // NC
        PaddleTensor& scores_tensor, // N
        PaddleTensor& labels_tensor, // N
        PaddleTensor& bboxes_tensor, // NB, inplace
        PaddleTensor& anchors_tensor, // NB, inplace
        const ImplProbDtype& score_threshold,
        const ImplBboxDtype& area_threshold,
        const ImplBboxDtype& xmin, const ImplBboxDtype& xmax,
        const ImplBboxDtype& ymin, const ImplBboxDtype& ymax);

#undef ImplProbDtype
#undef ImplLabelDtype

template void bbox_xywh2xyxy<ImplBboxDtype>(PaddleTensor& bboxes_tensor);

template void bbox_decode<ImplBboxDtype>(
        PaddleTensor& bboxes_tensor,  // NB, inplace
        const PaddleTensor& anchors_tensor, // NB
        ImplBboxDtype rweight_cx, ImplBboxDtype rweight_cy,
        ImplBboxDtype rweight_width, ImplBboxDtype rweight_height);

#define ImplKeypointDtype float

template void marker_postprocess<ImplKeypointDtype, ImplBboxDtype>(
        PaddleTensor& keypoints_tensor, // NB, inplace
        const PaddleTensor& bboxes_tensor, // NB
        ImplBboxDtype rweight);

#undef ImplKeypointDtype
#undef ImplBboxDtype

} //namespace marker
} // namespace vp
