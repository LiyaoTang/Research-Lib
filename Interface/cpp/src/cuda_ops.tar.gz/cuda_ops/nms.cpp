
#include "nms.h"

#include <algorithm>
#include <cassert>

namespace vp
{
namespace marker
{

// arrange, raw version
template <typename T>
static void arrange(
        T* __restrict__ const data,
        const T& start, const T& end)
{
    auto ptr = data;
    for (T value = start; value < end; ++value)
    {
        *(ptr++) = value;
    }
}

// area
#pragma omp declare simd
template <typename TB>
static TB area(const TB* __restrict__ const bbox)
{
    const auto& x0 = bbox[0];
    const auto& y0 = bbox[1];
    const auto& x1 = bbox[2];
    const auto& y1 = bbox[3];

    return (x1 + 1 - x0) * (y1 + 1 - y0);
}

// area, raw version, NB layout: N * Bbox
template <typename TB>
static void area(
        const TB* __restrict__ const bboxes_data_nb,
        TB* __restrict__ const areas_data,
        size_t size)
{
#pragma omp simd
    for (size_t idx = 0; idx < size; ++idx)
    {
        const auto bbox = bboxes_data_nb + idx * 4;
        areas_data[idx] = area(bbox);
    }
}

// nms, raw version, output indices
template <typename TB, typename TI,
          typename TR>
size_t nms_index(
        const TB* __restrict__ const bboxes_data_nb,
        TI* __restrict__ const out_indices_data,
        TB* __restrict__ const areas_data,
        size_t num_rois,
        const TR& threshold,
        size_t top_k)
{
    // calc area
    area(bboxes_data_nb, areas_data, num_rois);
    // init index
    arrange(out_indices_data, TI(0), TI(num_rois));

    // loop remained index
    size_t num_selected = 0;
    for (size_t low = 0; low < num_rois; ++low)
    {
        const auto low_bbox = bboxes_data_nb + low * 4;
        const auto& lx0 = low_bbox[0];
        const auto& ly0 = low_bbox[1];
        const auto& lx1 = low_bbox[2];
        const auto& ly1 = low_bbox[3];
        const auto& low_area = areas_data[low];

        // loop selected index
        bool keep = true;
        for (size_t high = 0; high < num_selected; ++high)
        {
            const auto high_bbox = bboxes_data_nb + high * 4;
            const auto ix0 = std::max(lx0, high_bbox[0]);
            const auto iy0 = std::max(ly0, high_bbox[1]);
            const auto ix1 = std::min(lx1, high_bbox[2]);
            const auto iy1 = std::min(ly1, high_bbox[3]);
            const auto iw = std::max(TB(0), ix1 - ix0 + 1);
            const auto ih = std::max(TB(0), iy1 - iy0 + 1);
            const auto iarea = iw * ih;

            assert(low_area + areas_data[high] - iarea > 0);

            const auto iou = TR(iarea) / TR(low_area + areas_data[high] - iarea);

            if (iou > threshold)
            {
                keep = false;
                break;
            }
        }

        if (keep)
        {
            out_indices_data[num_selected++] = TI(low);
            if (num_selected >= top_k)
            {
                break;
            }
        }
    }

    return num_selected;
}

// nms_unordered, raw version, output indices
template <typename TB, typename TS,  typename TI,
          typename TR>
size_t nms_index(
        const TB* __restrict__ const bboxes_data_nb, const TS* __restrict__ const scores_data,
        TI* __restrict__ const out_indices_data,
        TB* __restrict__ const areas_data,
        size_t num_rois,
        const TR& threshold,
        size_t top_k)
{
    // init index
    arrange(out_indices_data, TI(0), TI(num_rois));
    // sort index
    std::sort(out_indices_data, out_indices_data + num_rois, [&](const TI& a, const TI& b)
    {
        return scores_data[a] > scores_data[b];
    });

    // calc area
    area(bboxes_data_nb, areas_data, num_rois); // HINT: area - index order

    // loop remained index
    size_t num_selected = 0;
    for (size_t idx_low = 0; idx_low < num_rois; ++idx_low)
    {
        const auto low = out_indices_data[idx_low];
        const auto low_bbox = bboxes_data_nb + low * 4;
        const auto& lx0 = low_bbox[0];
        const auto& ly0 = low_bbox[1];
        const auto& lx1 = low_bbox[2];
        const auto& ly1 = low_bbox[3];
        const auto& low_area = areas_data[low];

        // loop selected index
        bool keep = true;
        for (size_t idx_high = 0; idx_high < num_selected; ++idx_high)
        {
            const auto high = out_indices_data[idx_high];
            const auto high_bbox = bboxes_data_nb + high * 4;
            const auto ix0 = std::max(lx0, high_bbox[0]);
            const auto iy0 = std::max(ly0, high_bbox[1]);
            const auto ix1 = std::min(lx1, high_bbox[2]);
            const auto iy1 = std::min(ly1, high_bbox[3]);
            const auto iw = std::max(TB(0), ix1 - ix0 + 1);
            const auto ih = std::max(TB(0), iy1 - iy0 + 1);
            const auto iarea = iw * ih;

            assert(low_area + areas_data[high] - iarea > 0);

            const auto iou = TR(iarea) / TR(low_area + areas_data[high] - iarea);

            if (iou > threshold)
            {
                keep = false;
                break;
            }
        }

        if (keep)
        {
            out_indices_data[num_selected++] = low;
            if (num_selected >= top_k)
            {
                break;
            }
        }
    }

    return num_selected;
}

// nms, raw version, output bboxes
template <typename TB,
          typename TR>
size_t nms_bbox(
        const TB* __restrict__ const bboxes_data_nb,
        TB* __restrict__ const out_bboxes_data_nb,
        size_t* __restrict__ const indices_data, TB* __restrict__ const areas_data,
        size_t num_rois,
        const TR& threshold,
        size_t top_k)
{
    const auto num_selected = nms_index(
                bboxes_data_nb,
                indices_data,
                areas_data,
                num_rois,
                threshold,
                top_k);

    auto dst_ptr = out_bboxes_data_nb;
    for (size_t idx_src = 0; idx_src < num_selected; ++idx_src)
    {
        const auto src = indices_data[idx_src];
        dst_ptr = std::copy_n(bboxes_data_nb + src * 4, 4, dst_ptr);
    }

    return num_selected;
}

// nms_unordered, raw version, output bboxes
template <typename TB, typename TS,
          typename TR>
size_t nms_bbox(
        const TB* __restrict__ const bboxes_data_nb, const TS* __restrict__ const scores_data,
        TB* __restrict__ const out_bboxes_data_nb,
        size_t* __restrict__ const indices_data, TB* __restrict__ const areas_data,
        size_t num_rois,
        const TR& threshold,
        size_t top_k)
{
    const auto num_selected = nms_index(
                bboxes_data_nb, scores_data,
                indices_data,
                areas_data,
                num_rois,
                threshold,
                top_k);

    auto dst_ptr = out_bboxes_data_nb;
    for (size_t idx_src = 0; idx_src < num_selected; ++idx_src)
    {
        const auto src = indices_data[idx_src];
        dst_ptr = std::copy_n(bboxes_data_nb + src * 4, 4, dst_ptr);
    }

    return num_selected;
}


#define ImplBboxDtype float
#define ImplIndexDtype int64_t

template size_t nms_index<ImplBboxDtype, ImplIndexDtype>(
        const ImplBboxDtype* __restrict__ const bboxes_data_nb,
        ImplIndexDtype* __restrict__ const out_indices_data,
        ImplBboxDtype* __restrict__ const areas_data,
        size_t num_rois,
        const float& threshold,
        size_t top_k);

#define ImplScoreDtype float

template size_t nms_index<ImplBboxDtype, ImplScoreDtype, ImplIndexDtype>(
        const ImplBboxDtype* __restrict__ const bboxes_data_nb,
        const ImplScoreDtype* __restrict__ const scores_data,
        ImplIndexDtype* __restrict__ const out_indices_data,
        ImplBboxDtype* __restrict__ const areas_data,
        size_t num_rois,
        const float& threshold,
        size_t top_k);

#undef ImplIndexDtype

template size_t nms_bbox<ImplBboxDtype>(
        const ImplBboxDtype* __restrict__ const bboxes_data_nb,
        ImplBboxDtype* __restrict__ const out_bboxes_data_nb,
        size_t* __restrict__ const indices_data, ImplBboxDtype* __restrict__ const areas_data,
        size_t num_rois,
        const float& threshold,
        size_t top_k);

template size_t nms_bbox<ImplBboxDtype, ImplScoreDtype>(
        const ImplBboxDtype* __restrict__ const bboxes_data_nb,
        const ImplScoreDtype* __restrict__ const scores_data,
        ImplBboxDtype* __restrict__ const out_bboxes_data_nb,
        size_t* __restrict__ const indices_data, ImplBboxDtype* __restrict__ const areas_data,
        size_t num_rois,
        const float& threshold,
        size_t top_k);

#undef ImplScoreDtype
#undef ImplBboxDtype

} //namespace marker
} // namespace vp
