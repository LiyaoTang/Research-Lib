
#include "camera_param.h"

#include <fcntl.h>

#include <glog/logging.h>

#include <google/protobuf/io/zero_copy_stream_impl.h>
#include <google/protobuf/text_format.h>

namespace baidu {
namespace idg {
namespace node {
namespace vpdps {

inline bool is_camera_fisheye_by_name(CameraParams::CameraName camera_name)
{
    using CameraName = CameraParams::CameraName;

    switch (camera_name)
    {
        case CameraName::CameraParameter_CameraNameType_front_middle_camera:
        case CameraName::CameraParameter_CameraNameType_rear_middle_camera:
        case CameraName::CameraParameter_CameraNameType_front_wide_camera:
        {
            return false;
        }
        case CameraName::CameraParameter_CameraNameType_front_short_camera:
        case CameraName::CameraParameter_CameraNameType_rear_short_camera:
        case CameraName::CameraParameter_CameraNameType_rear_right_camera:
        case CameraName::CameraParameter_CameraNameType_rear_left_camera:
        case CameraName::CameraParameter_CameraNameType_left_short_camera:
        case CameraName::CameraParameter_CameraNameType_right_short_camera:
        {
            return true;
        }
        default:
        {
            VLOG(2)  << "unhandled camera name: " << camera_name;

            return {};
        }
    }
}

CameraParams::CameraParams(const std::string& config_path)
{
    load(config_path);
}

CameraParams::~CameraParams() = default;

bool CameraParams::inited() const
{
    return _inited;
}

const CameraParam* CameraParams::get(CameraName name) const
{
    if (!_inited)
    {
        VLOG(1)  << "trying to get before inited";
    }

    auto it = _data.find(name);
    if (it == _data.cend())
    {
        return nullptr;
    }

    return &it->second;
}

//const CameraParam* CameraParams::get(CameraName name)
//{
//    if (!_inited)
//    {
//        load();
//    }

//    auto it = _data.find(name);
//    if (it == _data.cend())
//    {
//        return nullptr;
//    }

//    return &it->second;
//}

bool CameraParams::load(const std::string& config_path, real_t scale)
{
    _inited = false;
    _data.clear();
    autopilot_hardware::HardwareConfig hardware_config;
    {
        auto fd = open(config_path.c_str(), O_RDONLY | O_CLOEXEC);
        if (fd == -1)
        {
            LOG(FATAL)
                    << "failed to open HardwareConfig<"
                    << config_path
                    << ">";

            auto ret = close(fd);
            (void)ret;
            return _inited;
        }
        google::protobuf::io::FileInputStream stream { fd };
        auto ret = google::protobuf::TextFormat::Parse(&stream, &hardware_config);
        if (!ret)
        {
            LOG(FATAL)
                    << "HardwareConfig<"
                    << config_path
                    << "> parse error: " << stream.GetErrno();

            auto ret = close(fd);
            (void)ret;
            return _inited;
        }
    }

    auto& sensor_config = hardware_config.sensor_config();
    for (int idx_cam = 0; idx_cam < sensor_config.cam_param_size(); ++idx_cam)
    {
        auto& cam_param = sensor_config.cam_param(idx_cam);

        CHECK(_data.find(cam_param.name()) == _data.cend());

        CameraParam param;
        param.is_fisheye = is_camera_fisheye_by_name(cam_param.name());

        // for resize param
        param.width = int32_t(cam_param.image_width() * scale);
        param.height = int32_t(cam_param.image_height() * scale);
        param.fx = real_t(cam_param.fx() * scale);
        param.fy = real_t(cam_param.fy() * scale);
        param.cx = real_t(cam_param.cx() * scale);
        param.cy = real_t(cam_param.cy() * scale);

        param.yaw = real_t(cam_param.rotation().yaw());
        param.pitch = real_t(cam_param.rotation().pitch());
        param.roll = real_t(cam_param.rotation().roll());
        param.translation << real_t(cam_param.translation().x()),
                real_t(cam_param.translation().y()),
                real_t(cam_param.translation().z());
        param.update_inv_k();

        if (param.is_fisheye)
        {
            CHECK_EQ(cam_param.distortion_size(), 4);
            param.dist_coeffs = Vector(cam_param.distortion_size(), 1);
            param.dist_coeffs << real_t(cam_param.distortion(0) * scale),
                    real_t(cam_param.distortion(1) * scale),
                    real_t(cam_param.distortion(2) * scale),
                    real_t(cam_param.distortion(3) * scale);

        }
        else
        {
            CHECK_EQ(cam_param.distortion_size(), 5);
            param.dist_coeffs = Vector(cam_param.distortion_size(), 1);
            param.dist_coeffs << real_t(cam_param.distortion(0)),
                    real_t(cam_param.distortion(1) * scale),
                    real_t(cam_param.distortion(2) * scale),
                    real_t(cam_param.distortion(3) * scale),
                    real_t(cam_param.distortion(4) * scale);
        }
        _data.emplace(std::make_pair(cam_param.name(), param));
    }

    _inited = true;
    return _inited;
}

} // namespace vpdps
} // namespace node
} // namespace idg
} // namespace baidu
