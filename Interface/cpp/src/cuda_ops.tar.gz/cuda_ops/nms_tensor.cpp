
#include "nms_tensor.h"

#include <cassert>

#include "nms.h"

namespace frw = paddle_mobile::framework;

namespace vp
{
namespace marker
{

// nms, tensor version, output indices
template <typename BboxDtype,
          typename IndexDtype, typename IouType>
auto nms(
        const frw::Tensor& bboxes_tensor,
        frw::Tensor& out_tensor,
        const IouType& threshold,
        size_t top_k)
    -> typename std::enable_if<!std::is_same<IndexDtype, void>::value, size_t>::type
{
    // empty input specialization
    if (bboxes_tensor.numel() == 0)
    {
        out_tensor.Resize({ 0 });
        return 0;
    }

    assert(bboxes_tensor.dims().size() == 2); // NB
    assert(bboxes_tensor.dims()[1] == 4); // N * 4

    const auto num_rois = bboxes_tensor.dims()[0];
    const auto bboxes_data_nb = bboxes_tensor.data<BboxDtype>();

    frw::Tensor area_tensor;
    auto areas_data = area_tensor.mutable_data<BboxDtype>({ num_rois });
    auto out_indices_data = out_tensor.mutable_data<IndexDtype>({ num_rois });

    const auto num_selected = nms_index(
                bboxes_data_nb,
                out_indices_data,
                areas_data,
                size_t(num_rois),
                threshold,
                top_k);

    out_tensor.Resize({ int64_t(num_selected) });
    return num_selected;
}

// nms, tensor version, output bboxes
template <typename BboxDtype,
          typename IndexDtype, typename IouType>
auto nms(
        const frw::Tensor& bboxes_tensor,
        frw::Tensor& out_tensor,
        const IouType& threshold,
        size_t top_k)
    -> typename std::enable_if<std::is_same<IndexDtype, void>::value, size_t>::type
{
    // empty input specialization
    if (bboxes_tensor.numel() == 0)
    {
        out_tensor.Resize(bboxes_tensor.dims());
        return 0;
    }

    assert(bboxes_tensor.dims().size() == 2); // NB
    assert(bboxes_tensor.dims()[1] == 4); // N * 4

    const auto num_rois = bboxes_tensor.dims()[0];
    const auto bboxes_data_nb = bboxes_tensor.data<BboxDtype>();

    frw::Tensor indices_tensor, area_tensor;
    auto indices_data = indices_tensor.mutable_data<size_t>({ num_rois });
    auto areas_data = area_tensor.mutable_data<BboxDtype>({ num_rois });
    auto out_dims = bboxes_tensor.dims();
    auto out_bboxes_data_nb = out_tensor.mutable_data<BboxDtype>(out_dims);

    const auto num_selected = nms_bbox(
                bboxes_data_nb,
                out_bboxes_data_nb,
                indices_data, areas_data,
                size_t(num_rois),
                threshold,
                top_k);

    out_dims[0] = num_selected;
    out_tensor.Resize(out_dims);
    return num_selected;
}

// nms_unordered, tensor version, output indices
template <typename BboxDtype, typename ScoreDtype,
          typename IndexDtype, typename IouType>
auto nms(
        const frw::Tensor& bboxes_tensor, const frw::Tensor& scores_tensor,
        frw::Tensor& out_tensor,
        const IouType& threshold,
        size_t top_k)
    -> typename std::enable_if<!std::is_same<IndexDtype, void>::value, size_t>::type
{
    // empty input specialization
    if (bboxes_tensor.numel() == 0)
    {
        out_tensor.Resize({ 0 });
        return 0;
    }

    assert(bboxes_tensor.dims().size() == 2); // NB
    assert(bboxes_tensor.dims()[1] == 4); // N * 4

    const auto num_rois = bboxes_tensor.dims()[0];

    assert(scores_tensor.dims().size() == 1); // N
    assert(num_rois == scores_tensor.dims()[0]); // N == N

    const auto bboxes_data_nb = bboxes_tensor.data<BboxDtype>();
    const auto scores_data = scores_tensor.data<ScoreDtype>();

    frw::Tensor area_tensor;
    auto areas_data = area_tensor.mutable_data<BboxDtype>({ num_rois });
    auto out_indices_data = out_tensor.mutable_data<IndexDtype>({ num_rois });

    const auto num_selected = nms_index(
                bboxes_data_nb, scores_data,
                out_indices_data,
                areas_data,
                size_t(num_rois),
                threshold,
                top_k);

    out_tensor.Resize({ int64_t(num_selected) });
    return num_selected;
}

// nms_unordered, tensor version, output bboxes
template <typename BboxDtype, typename ScoreDtype,
          typename IndexDtype, typename IouType>
auto nms(
        const frw::Tensor& bboxes_tensor, const frw::Tensor& scores_tensor,
        frw::Tensor& out_tensor,
        const IouType& threshold,
        size_t top_k)
    -> typename std::enable_if<std::is_same<IndexDtype, void>::value, size_t>::type
{
    // empty input specialization
    if (bboxes_tensor.numel() == 0)
    {
        out_tensor.Resize(bboxes_tensor.dims());
        return 0;
    }

    assert(bboxes_tensor.dims().size() == 2); // NB
    assert(bboxes_tensor.dims()[1] == 4); // N * 4

    const auto num_rois = bboxes_tensor.dims()[0];

    assert(scores_tensor.dims().size() == 1); // N
    assert(num_rois == scores_tensor.dims()[0]); // N == N

    const auto bboxes_data_nb = bboxes_tensor.data<BboxDtype>();
    const auto scores_data = scores_tensor.data<ScoreDtype>();

    frw::Tensor indices_tensor, area_tensor;
    auto indices_data = indices_tensor.mutable_data<size_t>({ num_rois });
    auto areas_data = area_tensor.mutable_data<BboxDtype>({ num_rois });
    auto out_dims = bboxes_tensor.dims();
    auto out_bboxes_data_nb = out_tensor.mutable_data<BboxDtype>(out_dims);

    const auto num_selected = nms_bbox(
                bboxes_data_nb, scores_data,
                out_bboxes_data_nb,
                indices_data, areas_data,
                size_t(num_rois),
                threshold,
                top_k);

    out_dims[0] = num_selected;
    out_tensor.Resize(out_dims);
    return num_selected;
}


#define ImplBboxDtype float
#define ImplIndexDtype int64_t

template size_t nms<ImplBboxDtype, ImplIndexDtype>(
        const frw::Tensor&,
        frw::Tensor&,
        const float& threshold,
        size_t top_k);

template size_t nms<ImplBboxDtype>(
        const frw::Tensor&,
        frw::Tensor&,
        const float& threshold,
        size_t top_k);

#define ImplScoreDtype float

template size_t nms<ImplBboxDtype, ImplScoreDtype, ImplIndexDtype>(
        const frw::Tensor&, const frw::Tensor&,
        frw::Tensor&,
        const float& threshold,
        size_t top_k);

template size_t nms<ImplBboxDtype, ImplScoreDtype>(
        const frw::Tensor&, const frw::Tensor&,
        frw::Tensor&,
        const float& threshold,
        size_t top_k);

#undef ImplScoreDtype
#undef ImplIndexDtype
#undef ImplBboxDtype

} //namespace marker
} // namespace vp
