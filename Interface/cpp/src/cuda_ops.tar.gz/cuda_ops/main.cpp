
#include <cassert>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <map>
#include <numeric>
#include <regex>
#include <sstream>
#include <string>
#include <tuple>
#include <type_traits>
#include <vector>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>

#include "common/log.h"
#include "io/paddle_inference_api.h"

#include "camera_param.h"
#include "nms_ptensor.h"
#include "roi_align_ptensor.h"
#include "postprocess_ptensor.h"

#include "image_feature.pb.h"

namespace fpga = paddle_mobile::fpga;

using FeatureDtype = float;
using ProbDtype = float;
using BboxDtype = float;
using KeypointDtype = float;
using IndexDtype = int64_t;
using LabelDtype = int64_t;
using paddle_mobile::PaddleTensor;

using baidu::idg::node::vpdps::Vector2;
using baidu::idg::node::vpdps::CameraParam;
using baidu::idg::node::vpdps::CameraParams;
using baidu::pavaro::Header;
using baidu::idg::vp_em::Marker;
using baidu::idg::vp_em::ImageSource;
using baidu::idg::vp_em::ImageMarker;
using baidu::idg::vp_em::VPMarker;

//using ModelInfo = std::tuple<std::string, std::string>;
using ModelInfo = std::pair<std::string, std::string>;
using Predictors = std::vector<std::unique_ptr<paddle_mobile::PaddlePredictor>>;
using PaddleShape = std::vector<int>;
using PaddleTensors = std::vector<PaddleTensor>;

static const PaddleShape::value_type g_num_rois_limit = 10;
static const size_t g_roi_align_size = 14;
static const size_t g_roi_align_sampling_ratio = 0;
static constexpr float g_nms_threshold = .3f;
static constexpr float g_roi_align_spatial_scale = 0.0625f;

static const std::string g_hardware_config_path =
        "/home/luonairui/Workspace/Work/baidu/vp/vps-apollo/data/car_config/MKZ009/hardware_config.prototxt";
static const std::string g_path_base = "../vp_marker/";
static const std::string g_path_model_folder = g_path_base + "model/";
static const std::string g_path_data_folder = g_path_base + "data/";
static const std::vector<ModelInfo> g_path_model_infos {
    { g_path_model_folder + "0/model", g_path_model_folder + "0/params" },
    { g_path_model_folder + "1/model", g_path_model_folder + "1/params" },
};

template <template <typename...> class C, typename T>
static T product(const C<T>& sequence)
{
    return std::accumulate(std::begin(sequence), std::end(sequence),
                           T(1), std::multiplies<T>());
}

template <typename Dtype>
static const Dtype* _data(const PaddleTensor& tensor)
{
    return reinterpret_cast<const Dtype*>(tensor.data.data());
}

template <typename Dtype>
static Dtype* _data(PaddleTensor& tensor)
{
    return reinterpret_cast<Dtype*>(tensor.data.data());
}

template <typename Dtype>
static Dtype* _mutable_data(PaddleTensor& tensor, const PaddleShape& shape)
{
    assert(!shape.empty() && shape[0] >= 0);
    const auto numel = product(shape);
    tensor.data.Resize(numel * sizeof(Dtype));
    tensor.shape = shape;
    return reinterpret_cast<Dtype*>(tensor.data.data());
}

template <typename Dtype>
static void _tofile(const PaddleTensor& tensor,
                    const std::string name = "",
                    const std::string prefix = "")
{
//    assert(std::type_index { typeid(Dtype) } == tensor.dtypeid); // ENFORCED
    const auto name_ = name.empty() ? tensor.name : name;
    assert(!name_.empty());
    const auto numel = product(tensor.shape);
    const auto size = numel * sizeof(Dtype);
    {
        std::ofstream fs(prefix + name_ + ".bin", std::ios::out | std::ios::binary);
        assert(fs.is_open());
        fs.write(reinterpret_cast<char*>(tensor.data.data()), size);
        fs.close();
    }
    {
        std::ofstream fs(prefix + name_ + ".txt", std::ios::out);
        assert(fs.is_open());
        fs << "name=" << tensor.name << std::endl;
        fs << "layout=" << tensor.layout << std::endl;
        fs << "dtypeid=" << tensor.dtypeid.name() << std::endl;
        fs << "shape=";
        for (const auto& value: tensor.shape)
        {
            fs << value << ",";
        }
        fs << std::endl;
        fs.close();
    }
}

static std::chrono::microseconds::rep get_sys_time_us()
{
    return std::chrono::duration_cast<std::chrono::microseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count();
}

static PaddleShape resolve_indices(size_t index, const PaddleShape& shape)
{
    assert(!shape.empty());
    PaddleShape indices(shape.size());
    auto dim = shape.size();
    do
    {
        --dim;
        indices[dim] = index % shape[dim];
        index /= shape[dim];
    } while (dim > 0);
    return indices;
}

// float only
static bool has_nan(const PaddleTensor& tensor)
{
    assert(std::type_index { typeid(float) } == tensor.dtypeid);
    const auto shape = tensor.shape;
    const auto numel = size_t(product(shape));
    const auto data = reinterpret_cast<float*>(tensor.data.data());

    for (size_t idx = 0; idx < numel; ++idx)
    {
        if (std::isnan(data[idx]))
        {
            DLOG << "nan appears at " << idx <<
                    " \t" << resolve_indices(idx, shape);
            return true;
        }
    }

    return false;
}

template <typename Dtype>
static bool tensor_check(const PaddleTensor& result_tensor, const PaddleTensor& expected_tensor,
                    double eps = 1e-4)
{
    DLOG << "======== tensor_check on " <<
            result_tensor.name << " vs " << expected_tensor.name <<
            " ========";
    DLOG << "shape: \t" << result_tensor.shape << " \tvs \t" << expected_tensor.shape;

    DLOG << "has nan: " << has_nan(result_tensor) << " \tvs \t" << has_nan(expected_tensor);

    if (std::is_floating_point<Dtype>::value)
    {
        DLOG << "using precision: " << eps;
    }
    else
    {
        DLOG << "using precision: accurate";
    }

    if (result_tensor.shape != expected_tensor.shape)
    {
        DLOG << "======== test passed: 0: shape mismatch ========\n";

        return false;
    }

    const size_t num_ng_print_limit = 10;
    const auto shape = expected_tensor.shape;
    const auto numel = size_t(product(shape));
    const auto result_data = _data<Dtype>(result_tensor);
    const auto expected_data = _data<Dtype>(expected_tensor);
    size_t num_ng = 0, num_err = 0;
    double abs_err_sum = 0, rel_err_sum = 0;
    for (size_t idx = 0; idx < numel; ++idx)
    {
        const auto output = result_data[idx];
        const auto target = expected_data[idx];

        if (std::is_floating_point<Dtype>::value)
        {
            const auto output_ = double(output);
            const auto target_ = double(target);

            if (std::isnan(output_) && std::isnan(target_))
            {
                continue;
            }

            if (std::isnan(output) != std::isnan(target))
            {
                if (num_ng < num_ng_print_limit)
                {
                    DLOG << "differs at " << idx <<
                            " \t" << resolve_indices(idx, shape) << "\t: " <<
                            output << " \tvs \t" << target;
                }
                else if (num_ng == num_ng_print_limit)
                {
                    DLOG << "...";
                }
                num_ng += 1;
                continue;
            }

            const auto abs_err = std::abs(output_ - target_);
            const auto rel_err = abs_err / std::max(1., std::abs(target_));
            abs_err_sum += abs_err;
            rel_err_sum += rel_err;
            num_err += 1;
            if (rel_err > eps)
            {
                if (num_ng < num_ng_print_limit)
                {
                    DLOG << "differs at " << idx <<
                            " \t" << resolve_indices(idx, shape) << "\t: " <<
                            output << " \tvs \t" << target;
                }
                else if (num_ng == num_ng_print_limit)
                {
                    DLOG << "...";
                }
                num_ng += 1;
                continue;
            }
        }
        else
        {
            if (output != target)
            {
                if (num_ng < num_ng_print_limit)
                {
                    DLOG << "differs at " << idx <<
                            " \t" << resolve_indices(idx, shape) << "\t: " <<
                            output << " \tvs \t" << target;
                }
                else if (num_ng == num_ng_print_limit)
                {
                    DLOG << "...";
                }
                num_ng += 1;
            }
        }
    }

    if (num_ng > 0)
    {
        DLOG << "NGs: " << num_ng;
        if (std::is_floating_point<Dtype>::value && num_err > 0)
        {
            DLOG << "average abs error:" << abs_err_sum / num_err <<
                    ", average rel error:" << rel_err_sum * 100 / num_err << "%";
        }
    }

    DLOG << "======== test passed: " << (num_ng == 0) << ": " <<
            result_tensor.name << " vs " << expected_tensor.name <<
            " ========\n";
    return num_ng == 0;
}

static std::string make_data_filename(const std::string& tensor_name)
{
    return g_path_data_folder + tensor_name + ".bin";
}

static std::string make_meta_filename(const std::string& tensor_name)
{
    return g_path_data_folder + tensor_name + ".txt";
}

static void read_file(const std::string& filename,
               char* buffer,
               size_t expected_size = 0)
{
    std::ifstream fs(filename, std::ios::in | std::ios::binary);
    assert(fs.is_open());

    fs.seekg(0, std::ios::end);
    const auto size = fs.tellg();
    assert(expected_size == 0 || size == expected_size); //

    fs.seekg(0, std::ios::beg);
    fs.read(buffer, size);
    fs.close();
}

template <typename T>
static std::vector<T> read_file(const std::string& filename)
{
    std::ifstream fs(filename, std::ios::in | std::ios::binary);
    assert(fs.is_open());

    fs.seekg(0, std::ios::end);
    const auto size = fs.tellg();
    assert(size % sizeof(T) == 0);
    std::vector<T> ret;
    ret.resize(size / sizeof(T));

    fs.seekg(0, std::ios::beg);
    fs.read(reinterpret_cast<char*>(ret.data()), size);
    fs.close();

    return ret;
}

template <typename T>
T* create_cpu_buffer_from_file(const std::string& filename, size_t numel)
{
    const auto size = numel * sizeof(T);
    auto buffer = new T[numel];
    read_file(filename, reinterpret_cast<char*>(buffer), size);
    return buffer;
}

std::map<std::string, PaddleShape> parse_meta_shape(const std::string& buffer)
{
    std::map<std::string, PaddleShape> ret;
    const auto it_match_end = std::sregex_iterator();
    std::smatch shape_match;
    std::regex shape_pattern("shape|.*\\.shape");
    std::regex key_value_pattern("(.+)\\s*=(.+)\\s*");
    std::regex int_pattern("\\d+");
    for (auto it_key_value_match = std::sregex_iterator(buffer.begin(), buffer.end(), key_value_pattern);
         it_key_value_match != it_match_end;
         ++it_key_value_match)
    {
        const auto& key_value_match = *it_key_value_match;
        if (key_value_match.size() != 3)
        {
            continue;
        }

        const auto key = key_value_match[1].str();
        if (!std::regex_match(key, shape_match, shape_pattern))
        {
            continue;
        }

        const auto& value = key_value_match[2].str();
        PaddleShape ints;
        std::transform(std::sregex_iterator(value.begin(), value.end(), int_pattern),
                       it_match_end,
                       std::back_inserter(ints),
                       [](const std::match_results<std::string::const_iterator>& int_match)
                       {
                           return std::stoi(int_match.str());
                       });
        ret.emplace(std::make_pair(key, ints));
    }
    return ret;
}

std::map<std::string, PaddleShape> parse_meta_file_shape(const std::string& name)
{
    auto buffer = read_file<char>(make_meta_filename(name));
    return parse_meta_shape(std::string { buffer.data() });
}

template <typename T>
T* create_fpga_buffer_from_file(const std::string& filename, size_t numel)
{
    const auto size = numel * sizeof(T);
    auto buffer = reinterpret_cast<T*>(fpga::fpga_malloc(size));
    read_file(filename, reinterpret_cast<char*>(buffer), size);
    return buffer;
}

PaddleTensor create_cpu_f32_hwc_tensor_from_file(const std::string& name)
{
    PaddleTensor tensor;
    tensor.name = name;
    tensor.shape = parse_meta_file_shape(name)["shape"];
    tensor.dtype = paddle_mobile::FLOAT32;
    tensor.layout = paddle_mobile::LAYOUT_HWC; // as default

    const auto numel = size_t(product(tensor.shape));
    const auto size = numel * sizeof(float);
    auto data = create_cpu_buffer_from_file<float>(make_data_filename(tensor.name), numel);

    tensor.data.Reset(data, size);
    return tensor;
}

Predictors create_predictors()
{
    auto ret = paddle_mobile::fpga::open_device();
//    assert(ret == 0); // CHECKIT: ENFORCED

    Predictors predictors;
    for (const auto& model_info: g_path_model_infos)
    {
        paddle_mobile::PaddleMobileConfig config;
        config.precision = paddle_mobile::PaddleMobileConfig::FP32;
        config.device = paddle_mobile::PaddleMobileConfig::kFPGA;
        config.batch_size = 1;
        config.optimize = true;
        config.quantification = false;
        config.lod_mode = true;
        config.thread_num = 1;
        std::tie(config.prog_file, config.param_file) = model_info;

        predictors.emplace_back(paddle_mobile::CreatePaddlePredictor(config));
    }

    return predictors;
}

void prepare_backbone_rpn(PaddleTensors& input_tensors)
{
    assert(input_tensors.empty());

    {
        PaddleTensor tensor;
        tensor.name = "workflow/img_info";
        tensor.shape = { 1, 3 };
        tensor.dtype = paddle_mobile::FLOAT32;
        tensor.layout = paddle_mobile::LAYOUT_HWC;

        float const_data[3] { 432.f, 1280.f, 432.f / 1280.f };
        const auto numel = size_t(product(tensor.shape));
        const auto size = sizeof(const_data);
        assert(numel * sizeof(float) == size);
        auto data = new float[numel];
        std::copy(std::begin(const_data), std::end(const_data), data);

        tensor.data.Reset(data, size);
        input_tensors.emplace_back(tensor);
    }

    {
        PaddleTensor tensor;
        tensor.name = "workflow/img";
        tensor.shape = { 1, 432, 1280, 3 };
        tensor.dtype = paddle_mobile::FLOAT32; // FeatureDtype or uint8
        tensor.layout = paddle_mobile::LAYOUT_HWC;

        const auto numel = size_t(product(tensor.shape));
        const auto size = numel * sizeof(float);
        auto data = create_fpga_buffer_from_file<float>(make_data_filename(tensor.name), numel);

        tensor.data.Reset(data, size);
        input_tensors.emplace_back(tensor);
    }
//    PaddleTensor img_tensor = create_cpu_f32_hwc_tensor_from_file(
//                "workflow/img"); //  // FeatureDtype or uint8
}

void finalize_backbone_rpn(
        PaddleTensors& input_tensors, PaddleTensors& output_tensors)
{
    const auto prefix = g_path_data_folder + "workflow/rpn_output_";
    _tofile<ProbDtype>(output_tensors[0], "cls_prob", prefix);
    _tofile<BboxDtype>(output_tensors[1], "bbox_pred", prefix);
    _tofile<BboxDtype>(output_tensors[2], "rois", prefix);
    _tofile<FeatureDtype>(output_tensors[3], "feature_map", prefix);
}

void forward_backbone_rpn(
        paddle_mobile::PaddlePredictor* predictor,
        PaddleTensors& input_tensors, PaddleTensors& output_tensors)
{
    prepare_backbone_rpn(input_tensors);
    output_tensors.resize(4);
    predictor->FeedPaddleTensors(input_tensors);
    predictor->Predict_From_To(0, -1);
    predictor->FetchPaddleTensors(&output_tensors);
    finalize_backbone_rpn(input_tensors, output_tensors);
}

void prepare_marker_head(PaddleTensors& input_tensors)
{

}

void finalize_marker_head(
        PaddleTensors& input_tensors, PaddleTensors& output_tensors)
{
    const auto prefix = g_path_data_folder + "workflow/marker_output_";
    _tofile<BboxDtype>(output_tensors[0], "keypoints", prefix);
}

void forward_marker_head(
        paddle_mobile::PaddlePredictor* predictor,
        PaddleTensors& input_tensors, PaddleTensors& output_tensors)
{
    prepare_marker_head(input_tensors);
    output_tensors.resize(1);
    predictor->FeedPaddleTensors(input_tensors);
    predictor->Predict_From_To(0, -1);
    predictor->FetchPaddleTensors(&output_tensors);
    finalize_marker_head(input_tensors, output_tensors);
}

void forward_roi_postprocess(
        PaddleTensors& input_tensors, PaddleTensors& output_tensors)
{
    PaddleTensor bboxes_tensor = input_tensors[0];
    PaddleTensor anchors_tensor = input_tensors[1];
    PaddleTensor cls_prob_tensor = input_tensors[2]; // CHECKIT: ensure softmax applied !!!
    PaddleTensor feature_map_tensor = input_tensors[3];
    PaddleTensor scores_tensor;
    PaddleTensor indices_tensor;
    PaddleTensor labels_tensor;
    PaddleTensor filtered_bboxes_tensor;
    PaddleTensor filtered_labels_tensor;
    PaddleTensor filtered_scores_tensor;
    PaddleTensor roi_features_tensor;

//    assert(bboxes_tensor.shape.size() == 2); // NB
//    assert(bboxes_tensor.shape[1] == 8); // CHECKIT: N * (4 + B)
//    assert(bboxes_tensor.shape == anchors_tensor.shape); // CHECKIT: (N * 4) == (N * 4)
    assert(anchors_tensor.shape.size() == 2); // NB
    assert(anchors_tensor.shape[1] == 4); // N * 4
    assert(cls_prob_tensor.shape.size() == 2); // NC

    const auto num_rois = cls_prob_tensor.shape[0];
    const auto num_labels = cls_prob_tensor.shape[1];

//    assert(num_rois == bboxes_tensor.shape[0]); // N == N
    assert(num_rois == anchors_tensor.shape[0]); // N == N
    assert(num_rois == cls_prob_tensor.shape[0]); // N == N

    // BOX DECODE OFF, CHECKIT: B8TO4
    bboxes_tensor = anchors_tensor;
    vp::marker::roi_filter<ProbDtype, LabelDtype, BboxDtype,
            false>(
                cls_prob_tensor,
                scores_tensor,
                labels_tensor,
                bboxes_tensor);
//    vp::marker::bbox_xywh2xyxy<BboxDtype>(bboxes_tensor);

//    // BOX DECODE ON
//    vp::marker::roi_filter<ProbDtype, LabelDtype, BboxDtype,
//            false>(
//                cls_prob_tensor,
//                scores_tensor,
//                labels_tensor,
//                bboxes_tensor,
//                anchors_tensor);
//    vp::marker::bbox_decode<BboxDtype>(bboxes_tensor, anchors_tensor);

    vp::marker::nms<BboxDtype, ProbDtype, IndexDtype>(
                bboxes_tensor, scores_tensor,
                indices_tensor,
                g_nms_threshold,
                g_num_rois_limit);

    vp::marker::index_select<BboxDtype, IndexDtype>(bboxes_tensor, indices_tensor, filtered_bboxes_tensor);
    vp::marker::index_select<LabelDtype, IndexDtype>(labels_tensor, indices_tensor, filtered_labels_tensor);
    vp::marker::index_select<ProbDtype, IndexDtype>(scores_tensor, indices_tensor, filtered_scores_tensor);

    vp::marker::roi_align<FeatureDtype, BboxDtype>(
                feature_map_tensor, filtered_bboxes_tensor, // standard
//                feature_map_tensor, input_tensors[0], // profile
                roi_features_tensor,
                g_roi_align_size, g_roi_align_size,
                g_roi_align_sampling_ratio,
                g_roi_align_spatial_scale);

    output_tensors = { roi_features_tensor,
                       filtered_bboxes_tensor, filtered_labels_tensor, filtered_scores_tensor };
}

void forward_marker_postprocess(
        PaddleTensors& input_tensors, PaddleTensors& output_tensors)
{
    PaddleTensor keypoints_tensor = input_tensors[0];
    PaddleTensor bboxes_tensor = input_tensors[1];

    vp::marker::marker_postprocess<KeypointDtype, BboxDtype>(keypoints_tensor, bboxes_tensor);

    output_tensors = { keypoints_tensor };
}

VPMarker push_markers(const PaddleTensors& tensors,
                  const CameraParam* const param = nullptr,
                  const PaddleTensor& img_tensor = PaddleTensor())
{
    PaddleTensor keypoints_tensor = tensors[0];
    PaddleTensor labels_tensor = tensors[1];
    PaddleTensor scores_tensor = tensors[2];

    const auto num_markers_ = labels_tensor.shape[0];
    const auto num_markers = size_t(num_markers_);
    const auto sys_time_us = get_sys_time_us();

    assert(keypoints_tensor.shape.size() == 2); // NP
    assert(num_markers == keypoints_tensor.shape[0]); // N == N
    assert(keypoints_tensor.shape[1] == 8); // N * (4 * 2)
    assert(labels_tensor.shape.size() == 1); // N
    assert(num_markers == labels_tensor.shape[0]); // N == N
    assert(scores_tensor.shape.size() == 1); // N
    assert(num_markers == scores_tensor.shape[0]); // N == N

    const auto labels_data = _data<LabelDtype>(labels_tensor);
    const auto scores_data = _data<ProbDtype>(scores_tensor);
    const auto keypoints_data_np = _data<KeypointDtype>(keypoints_tensor);

    const std::map<LabelDtype, std::string> label2text {
        { 1, "A01",  },
        { 2, "A02",  },
        { 3, "A03",  },
        { 4, "A04",  },
        { 5, "A05",  },
        { 6, "A06",  },
        { 7, "A07",  },
        { 8, "A08",  },
        { 9, "A09",  },
        { 10, "A10", },
        { 11, "B01", },
        { 12, "B02", },
        { 13, "B03", },
        { 14, "B04", },
        { 15, "B05", },
        { 16, "B06", },
        { 17, "B07", },
        { 18, "B08", },
        { 19, "B09", },
        { 20, "B10", },
        { 21, "C01", },
        { 22, "C02", },
        { 23, "C03", },
        { 24, "C04", },
        { 25, "C05", },
        { 26, "C06", },
        { 27, "C07", },
        { 28, "C08", },
        { 29, "C09", },
        { 30, "C10", },
        { 31, "D01", },
        { 32, "D02", },
        { 33, "D03", },
        { 34, "D04", },
        { 35, "D05", },
        { 36, "D06", },
        { 37, "D07", },
        { 38, "D08", },
        { 39, "D09", },
        { 40, "E01", },
        { 41, "E02", },
        { 42, "E03", },
        { 43, "E04", },
        { 44, "E05", },
        { 45, "E06", },
        { 46, "E07", },
        { 47, "E08", },
        { 48, "E09", },
        { 49, "F01", },
    };

    DLOG << "sys_time_us: " << sys_time_us;
    if (param == nullptr)
    {
        DLOG << "undistortion will not be applied";
    }

    cv::Mat img;
    if (!img_tensor.data.empty())
    {
        img = cv::Mat { img_tensor.shape[0], img_tensor.shape[1], CV_32FC3, img_tensor.data.data() };
        img.convertTo(img, CV_8UC3, 255. / 280., 120.);
    }

    VPMarker vp_marker;
    vp_marker.set_sys_time_us(sys_time_us);
    vp_marker.set_sensor_type(VPMarker::SensorType::VPMarker_SensorType_MARKER);
    auto image_marker = vp_marker.add_image_marker();
    image_marker->set_sys_time_us(sys_time_us);
    image_marker->set_image_source(ImageSource::CAMERA_FRONT);
    for (size_t idx_marker = 0; idx_marker < num_markers; ++idx_marker)
    {
        const auto label = labels_data[idx_marker];
        const auto score = scores_data[idx_marker];
        const auto keypoints = keypoints_data_np + idx_marker * 8;
        const auto text = label2text.at(label);

        std::vector<Vector2> image_points(4), norm_points(4);
        for (size_t idx_point = 0; idx_point < 4; ++idx_point)
        {
            const auto point = keypoints + ((idx_point + 1) % 4) * 2;
            image_points[idx_point] = { point[0], point[1] };
            norm_points[idx_point] = param->liftproject(image_points[idx_point]);
        }

        { // create message
            auto marker = image_marker->add_marker();
            marker->set_marker_id(label);
            marker->set_marker_text(text);
            for (size_t idx_point = 0; idx_point < 4; ++idx_point)
            {
                auto point_image = marker->add_point_image();
                point_image->set_x(image_points[idx_point].x());
                point_image->set_y(image_points[idx_point].y());
                auto point_norm = marker->add_point_norm();
                point_norm->set_x(norm_points[idx_point].x());
                point_norm->set_y(norm_points[idx_point].y());
            }
        }

        { // debug output
            std::stringstream ss;
            DLOG << "marker id: " << label << ", text: " << text << ", score: " << score;
            ss << "[ ";
            for (size_t idx_point = 0; idx_point < 4; ++idx_point)
            {
                ss << "(" << image_points[idx_point][0] << "," << image_points[idx_point][1] << "), ";
            }
            ss << "]";
            DLOG << "\t point_image: " << ss.str();
            ss.str({});
            ss << "[ ";
            for (size_t idx_point = 0; idx_point < 4; ++idx_point)
            {
                ss << "(" << norm_points[idx_point][0] << "," << norm_points[idx_point][1] << "), ";
            }
            ss << "]";
            DLOG << "\t point_norm: " << ss.str();
        }

        if (!img.empty())
        {
            std::vector<cv::Point> points(4);
            for (size_t idx_point = 0; idx_point < 4; ++idx_point)
            {
                const auto point = keypoints + idx_point * 2;
                points[idx_point] = { int(std::round(point[0])), int(std::round(point[1])) };
            }
            cv::drawContours(img, std::vector<std::vector<cv::Point>> { points }, 0,
                             cv::Scalar(80, 240, 80), 2);
            cv::putText(img, text, points[0], CV_FONT_HERSHEY_PLAIN, 1.2, cv::Scalar(0, 240, 240));
        }
    }

    if (!img.empty())
    {
        cv::Mat img_show;
        const std::string win_name = "visualization";
        cv::namedWindow(win_name, CV_WINDOW_NORMAL);
        cv::resizeWindow(win_name, img.cols, img.rows);
        cv::imshow(win_name, img);
        cv::imwrite(win_name + ".png", img);
        cv::waitKey();
    }

    return vp_marker;
}

void workflow()
{
    auto predictors = create_predictors();

    // img_info, img
    PaddleTensors backbone_rpn_inputs;
    // cls_prob, bbox_pred, rois, feature_map(s)
    PaddleTensors backbone_rpn_outputs;
    forward_backbone_rpn(predictors[0].get(), backbone_rpn_inputs, backbone_rpn_outputs);

    // bbox_pred -> bboxes, rois -> anchors, cls_prob -> cls_prob, feature_map(s) -> feature_map(s)
    PaddleTensors roi_postprocess_inputs {
        backbone_rpn_outputs[1], backbone_rpn_outputs[2], backbone_rpn_outputs[0], backbone_rpn_outputs[3],
    };
    // roi_features, filtered_bboxes, filtered_labels, filtered_scores
    PaddleTensors roi_postprocess_outputs;
    forward_roi_postprocess(roi_postprocess_inputs, roi_postprocess_outputs);

    // roi_features -> data
    PaddleTensors marker_head_inputs {
        roi_postprocess_outputs[0],
    };
    PaddleTensors marker_head_outputs; // roi_heads.marker.feature_extracotr.fc_r2.fc
    forward_marker_head(predictors[1].get(), marker_head_inputs, marker_head_outputs);

    // roi_heads.marker.feature_extracotr.fc_r2.fc -> keypoints, filtered_bboxes -> bboxes
    PaddleTensors marker_postprocess_inputs {
        marker_head_outputs[0], roi_postprocess_outputs[1],
    };
    // keypoints
    PaddleTensors marker_postprocess_outputs;
    forward_marker_postprocess(marker_postprocess_inputs, marker_postprocess_outputs);

    // keypoints -> keypoints, filtered_labels -> labels, filtered_scores -> scores
    PaddleTensors results {
        marker_postprocess_outputs[0], roi_postprocess_outputs[2], roi_postprocess_outputs[3],
    };
    push_markers(results);
}

void test_cpu_0()
{
    DLOG << "======== TEST CPU 0 ========";
    PaddleTensor box_filtered_bboxes_tensor = create_cpu_f32_hwc_tensor_from_file(
                "valid/box_post_filtered_bbox"); // BboxDtype == float32
    PaddleTensor marker_bboxes_tensor = create_cpu_f32_hwc_tensor_from_file(
                "valid/marker_post_bbox"); // BboxDtype == float32

    tensor_check<BboxDtype>(box_filtered_bboxes_tensor, marker_bboxes_tensor);
}

void test_cpu_1()
{
    DLOG << "======== TEST CPU 1 ========";
    PaddleTensor bboxes_tensor = create_cpu_f32_hwc_tensor_from_file(
                "test/first_in_anchor"); // BboxDtype == float32
    PaddleTensor anchors_tensor = create_cpu_f32_hwc_tensor_from_file(
                "test/first_in_anchor"); // BboxDtype == float32
    PaddleTensor cls_prob_tensor = create_cpu_f32_hwc_tensor_from_file(
                "test/first_in_cls"); // ProbDtype == float32
    PaddleTensor feature_map_tensor = create_cpu_f32_hwc_tensor_from_file(
                "test/first_in_featuremap"); // FeatureDtype == float32

    // bbox_pred -> bboxes, rois -> anchors, cls_prob -> cls_prob, feature_map(s) -> feature_map(s)
    PaddleTensors roi_postprocess_inputs {
        bboxes_tensor, anchors_tensor, cls_prob_tensor, feature_map_tensor,
    };
    // roi_features, filtered_bboxes, filtered_labels, filtered_scores
    PaddleTensors roi_postprocess_outputs;
    auto t0 = get_sys_time_us();
    forward_roi_postprocess(roi_postprocess_inputs, roi_postprocess_outputs);
    auto t1 = get_sys_time_us();
    DLOG << "time: " << t1 - t0 << "us";

    PaddleTensor roi_features_tensor = create_cpu_f32_hwc_tensor_from_file(
                "test/roi_align_roi_features"); // FeatureDtype == float32
    PaddleTensor filtered_bboxes_tensor = create_cpu_f32_hwc_tensor_from_file(
                "test/box_post_filtered_bbox"); // BboxDtype == float32
    PaddleTensor filtered_scores_tensor = create_cpu_f32_hwc_tensor_from_file(
                "test/box_post_filtered_scores"); // ProbDtype == float32
    PaddleTensor filtered_labels_tensor;
    {
        PaddleTensor tensor;
        tensor.name = "test/box_post_filtered_cls";
        tensor.shape = parse_meta_file_shape(tensor.name)["shape"];
        tensor.dtype = paddle_mobile::INT64; // LabelDtype

        const auto numel = size_t(product(tensor.shape));
        const auto size = numel * sizeof(LabelDtype);
        auto data = create_cpu_buffer_from_file<LabelDtype>(make_data_filename(tensor.name), numel);

        tensor.data.Reset(data, size);
        filtered_labels_tensor = tensor;
    }

    tensor_check<FeatureDtype>(roi_postprocess_outputs[0], roi_features_tensor);
    tensor_check<BboxDtype>(roi_postprocess_outputs[1], filtered_bboxes_tensor);
    tensor_check<LabelDtype>(roi_postprocess_outputs[2], filtered_labels_tensor);
    tensor_check<ProbDtype>(roi_postprocess_outputs[3], filtered_scores_tensor);

    const auto prefix = g_path_data_folder + "test/box_post_output_";
    _tofile<FeatureDtype>(roi_postprocess_outputs[0], "roi_features", prefix);
    _tofile<BboxDtype>(roi_postprocess_outputs[1], "filtered_bboxes", prefix);
    _tofile<LabelDtype>(roi_postprocess_outputs[2], "filtered_labels", prefix);
    _tofile<ProbDtype>(roi_postprocess_outputs[3], "filtered_scores", prefix);
}

void test_cpu_2()
{
    DLOG << "======== TEST CPU 2 ========";
    PaddleTensor keypoints_tensor = create_cpu_f32_hwc_tensor_from_file(
                "test/marker_post_keypoints"); // KeypointDtype == float32
    PaddleTensor bboxes_tensor = create_cpu_f32_hwc_tensor_from_file(
                "test/marker_post_bbox"); // BboxDtype == float32

    // roi_heads.marker.feature_extracotr.fc_r2.fc -> keypoints, filtered_bboxes -> bboxes
    PaddleTensors marker_postprocess_inputs {
        keypoints_tensor, bboxes_tensor,
    };
    // keypoints
    PaddleTensors marker_postprocess_outputs;
    auto t0 = get_sys_time_us();
    forward_marker_postprocess(marker_postprocess_inputs, marker_postprocess_outputs);
    auto t1 = get_sys_time_us();
    DLOG << "time: " << t1 - t0 << "us";

    PaddleTensor out_keypoints_tensor = create_cpu_f32_hwc_tensor_from_file(
                "test/marker_post_output_keypoints"); // KeypointDtype == float32

    tensor_check<KeypointDtype>(marker_postprocess_outputs[0], out_keypoints_tensor);

    const auto prefix = g_path_data_folder + "test/marker_post_output_";
    _tofile<FeatureDtype>(marker_postprocess_outputs[0], "keypoints", prefix);
}

void test_push()
{
    DLOG << "======== TEST PUSH ========";
    PaddleTensor img_tensor = create_cpu_f32_hwc_tensor_from_file(
                "test/img"); //  // FeatureDtype or uint8
    PaddleTensor out_keypoints_tensor = create_cpu_f32_hwc_tensor_from_file(
                "test/marker_post_output_keypoints"); // KeypointDtype == float32
    PaddleTensor filtered_scores_tensor = create_cpu_f32_hwc_tensor_from_file(
                "test/box_post_filtered_scores"); // ProbDtype == float32
    PaddleTensor filtered_labels_tensor;
    {
        PaddleTensor tensor;
        tensor.name = "test/box_post_filtered_cls";
        tensor.shape = parse_meta_file_shape(tensor.name)["shape"];
        tensor.dtype = paddle_mobile::INT64; // LabelDtype

        const auto numel = size_t(product(tensor.shape));
        const auto size = numel * sizeof(LabelDtype);
        auto data = create_cpu_buffer_from_file<LabelDtype>(make_data_filename(tensor.name), numel);

        tensor.data.Reset(data, size);
        filtered_labels_tensor = tensor;
    }

    const CameraParams params { g_hardware_config_path };
    auto param = const_cast<CameraParam*>(
                params.get(CameraParams::CameraName::CameraParameter_CameraNameType_front_wide_camera));
    param->cy -= 720 - 432;
    param->update_inv_k();

    auto t0 = get_sys_time_us();
    auto message = push_markers(
                { out_keypoints_tensor, filtered_labels_tensor, filtered_scores_tensor },
                param, img_tensor);
    auto t1 = get_sys_time_us();
    DLOG << "time: " << t1 - t0 << "us";

    DLOG << "message:\n" << message.DebugString();
}

int main(int argc, char* argv[])
{
//    workflow();

//    test_cpu_0();
    test_cpu_1();
    test_cpu_2();
    test_push();

    return 0;
}
