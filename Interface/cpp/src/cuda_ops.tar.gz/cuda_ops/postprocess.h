
#pragma once

#include <cstddef>
#include <limits>

namespace vp
{
namespace marker
{

// select on dim 0, inplace not supported(restrict)
template <typename TD, typename TI>
void index_select(
        const TD* __restrict__ const src_data,
        const TI* __restrict__ const indices_data,
        TD* __restrict__ const dst_data,
        size_t count,
        size_t group_size = 1);

// roi_filter, raw + inplace version
template <typename TP, typename TL, typename TB,
          bool B8TO4 = false>
size_t roi_filter(
        const TP* __restrict__ const cls_prob_data_nc,
        TP* __restrict__ const scores_data,
        TL* __restrict__ const labels_data,
        TB* __restrict__ const bboxes_data_nb, // inplace
        size_t num_rois, size_t num_labels,
        const TP& score_threshold = TP(0),
        const TB& area_threshold = TB(0),
        const TB& xmin = std::numeric_limits<TB>::lowest(),
        const TB& xmax = std::numeric_limits<TB>::max(),
        const TB& ymin = std::numeric_limits<TB>::lowest(),
        const TB& ymax = std::numeric_limits<TB>::max());

// roi_filter, with anchors, raw + inplace version
template <typename TP, typename TL, typename TB,
          bool B8TO4 = false>
size_t roi_filter(
        const TP* __restrict__ const cls_prob_data_nc,
        TP* __restrict__ const scores_data,
        TL* __restrict__ const labels_data,
        TB* __restrict__ const bboxes_data_nb, // inplace
        TB* __restrict__ const anchors_data_nb, // inplace
        size_t num_rois, size_t num_labels,
        const TP& score_threshold = TP(0),
        const TB& area_threshold = TB(0),
        const TB& xmin = std::numeric_limits<TB>::lowest(),
        const TB& xmax = std::numeric_limits<TB>::max(),
        const TB& ymin = std::numeric_limits<TB>::lowest(),
        const TB& ymax = std::numeric_limits<TB>::max());

// bbox_xywh2xyxy, raw + inplace version
template <typename TB>
void bbox_xywh2xyxy(
        TB* __restrict__ const bboxes_data_nb, // inplace, rel xywh form -> abs xyxy form
        size_t num_rois,
        const TB& extra = TB(1));

// bbox_decode, raw + inplace version
template <typename TB>
void bbox_decode(
        TB* __restrict__ const bboxes_data_nb, // inplace, rel xywh form -> abs xyxy form
        const TB* __restrict__ const anchors_data_nb,
        size_t num_rois,
        const TB& rweight_cx = TB(1. / 1.), const TB& rweight_cy = TB(1. / 1.),
        const TB& rweight_width = TB(1. / 1.), const TB& rweight_height = TB(1. / 1.),
        const TB& extra = TB(1));

// keypoint_postprocess, raw + inplace version
template <typename TK, typename TB>
void keypoint_postprocess(
        TK* __restrict__ const keypoints_data_np, // inplace, rel xyxy form -> abs xyxy form
        const TB* __restrict__ const bboxes_data_nb,
        size_t num_rois, size_t num_keypoints = 4,
        const TB& rweight_x = TB(1. / 10.), const TB& rweight_y = TB(1. / 10.));

} //namespace marker
} // namespace vp
